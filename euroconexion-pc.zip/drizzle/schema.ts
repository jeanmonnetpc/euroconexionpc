import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow (for Manus OAuth - admin).
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Administrador del sistema - contraseña única
 */
export const admins = mysqlTable("admins", {
  id: int("id").autoincrement().primaryKey(),
  password: varchar("password", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = typeof admins.$inferInsert;

/**
 * Clases disponibles en el sistema
 */
export const classes = mysqlTable("classes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Class = typeof classes.$inferSelect;
export type InsertClass = typeof classes.$inferInsert;

/**
 * Profesores del sistema
 */
export const teachers = mysqlTable("teachers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = typeof teachers.$inferInsert;

/**
 * Relación profesor-clase (un profesor puede tener múltiples clases)
 */
export const teacherClasses = mysqlTable("teacher_classes", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(),
  classId: int("classId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TeacherClass = typeof teacherClasses.$inferSelect;
export type InsertTeacherClass = typeof teacherClasses.$inferInsert;

/**
 * Alumnos registrados
 */
export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  classId: int("classId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastAccess: timestamp("lastAccess").defaultNow().notNull(),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

/**
 * Puntuaciones de los alumnos en las actividades
 */
export const scores = mysqlTable("scores", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull(),
  activityType: mysqlEnum("activityType", ["quiz1", "quiz2", "quiz3", "roleplay", "escaperoom"]).notNull(),
  score: int("score").notNull().default(0),
  maxScore: int("maxScore").notNull().default(0),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
  timeSpent: int("timeSpent").default(0), // en segundos
});

export type Score = typeof scores.$inferSelect;
export type InsertScore = typeof scores.$inferInsert;

/**
 * Progreso del alumno en actividades
 */
export const studentProgress = mysqlTable("student_progress", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull(),
  quiz1Completed: boolean("quiz1Completed").default(false),
  quiz2Completed: boolean("quiz2Completed").default(false),
  quiz3Completed: boolean("quiz3Completed").default(false),
  roleplayCompleted: boolean("roleplayCompleted").default(false),
  escaperoomCompleted: boolean("escaperoomCompleted").default(false),
  totalPoints: int("totalPoints").default(0),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StudentProgress = typeof studentProgress.$inferSelect;
export type InsertStudentProgress = typeof studentProgress.$inferInsert;
