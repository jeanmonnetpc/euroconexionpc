import { cn } from "@/lib/utils";

interface EUStarsProps {
  className?: string;
  size?: number;
  animate?: boolean;
}

export function EUStars({ className, size = 100, animate = false }: EUStarsProps) {
  const starPositions = Array.from({ length: 12 }, (_, i) => {
    const angle = (i * 30 - 90) * (Math.PI / 180);
    const radius = 38;
    return {
      x: 50 + radius * Math.cos(angle),
      y: 50 + radius * Math.sin(angle),
    };
  });

  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={cn(animate && "eu-stars-animate", className)}
    >
      <circle cx="50" cy="50" r="48" fill="currentColor" className="text-eu-blue" />
      {starPositions.map((pos, i) => (
        <polygon
          key={i}
          points={getStarPoints(pos.x, pos.y, 5, 2.5)}
          fill="#FFD700"
        />
      ))}
    </svg>
  );
}

function getStarPoints(cx: number, cy: number, outerRadius: number, innerRadius: number): string {
  const points: string[] = [];
  for (let i = 0; i < 10; i++) {
    const angle = (i * 36 - 90) * (Math.PI / 180);
    const radius = i % 2 === 0 ? outerRadius : innerRadius;
    points.push(`${cx + radius * Math.cos(angle)},${cy + radius * Math.sin(angle)}`);
  }
  return points.join(" ");
}

export function EUFlag({ className, size = 200 }: { className?: string; size?: number }) {
  const starPositions = Array.from({ length: 12 }, (_, i) => {
    const angle = (i * 30 - 90) * (Math.PI / 180);
    const radius = 30;
    return {
      x: 50 + radius * Math.cos(angle),
      y: 50 + radius * Math.sin(angle),
    };
  });

  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={className}
    >
      <rect width="100" height="100" fill="#003399" rx="4" />
      {starPositions.map((pos, i) => (
        <polygon
          key={i}
          points={getStarPoints(pos.x, pos.y, 6, 3)}
          fill="#FFCC00"
        />
      ))}
    </svg>
  );
}
