import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { BookOpen } from "lucide-react";

// Diccionario de términos del glosario sobre la Unión Europea
export const glossaryTerms: Record<string, { definition: string; category: string }> = {
  // Instituciones
  "Parlamento Europeo": {
    definition: "Institución de la UE elegida directamente por los ciudadanos europeos cada 5 años. Representa a más de 440 millones de personas y aprueba leyes junto con el Consejo.",
    category: "Instituciones"
  },
  "Comisión Europea": {
    definition: "Órgano ejecutivo de la UE. Propone leyes, gestiona el presupuesto y vela por el cumplimiento de los tratados. Está formada por un comisario de cada país miembro.",
    category: "Instituciones"
  },
  "Consejo Europeo": {
    definition: "Reunión de los jefes de Estado o de Gobierno de los países de la UE. Define las orientaciones políticas generales de la Unión.",
    category: "Instituciones"
  },
  "Consejo de la UE": {
    definition: "También llamado Consejo de Ministros. Representa a los gobiernos de los Estados miembros y adopta leyes junto con el Parlamento Europeo.",
    category: "Instituciones"
  },
  "Tribunal de Justicia de la UE": {
    definition: "Máximo órgano judicial de la UE con sede en Luxemburgo. Garantiza que el Derecho europeo se interprete y aplique de la misma manera en todos los países.",
    category: "Instituciones"
  },
  "Banco Central Europeo": {
    definition: "Institución responsable de la política monetaria de la zona euro. Controla la inflación y supervisa los bancos. Tiene su sede en Fráncfort.",
    category: "Instituciones"
  },
  "Eurodiputado": {
    definition: "Miembro del Parlamento Europeo elegido por los ciudadanos. España tiene 59 eurodiputados que representan los intereses de los españoles en la UE.",
    category: "Instituciones"
  },

  // Tratados y acuerdos
  "Tratado de Roma": {
    definition: "Firmado en 1957, creó la Comunidad Económica Europea (CEE) y la Comunidad Europea de la Energía Atómica (Euratom). Es el origen de la actual UE.",
    category: "Tratados"
  },
  "Tratado de Maastricht": {
    definition: "Firmado en 1992, creó la Unión Europea tal como la conocemos. Estableció la ciudadanía europea, el euro y los tres pilares de la UE.",
    category: "Tratados"
  },
  "Tratado de Lisboa": {
    definition: "Firmado en 2007, reformó las instituciones de la UE para hacerlas más democráticas y eficientes. Creó el cargo de Presidente del Consejo Europeo.",
    category: "Tratados"
  },
  "Tratado de Schengen": {
    definition: "Acuerdo que eliminó los controles fronterizos entre los países firmantes. Permite viajar libremente por 27 países europeos sin mostrar el pasaporte.",
    category: "Tratados"
  },
  "CECA": {
    definition: "Comunidad Europea del Carbón y del Acero. Creada en 1951, fue la primera organización supranacional europea. Puso bajo control común el carbón y el acero de Francia y Alemania.",
    category: "Tratados"
  },
  "CEE": {
    definition: "Comunidad Económica Europea. Creada por el Tratado de Roma en 1957, estableció un mercado común entre los países miembros. Precursora de la actual UE.",
    category: "Tratados"
  },

  // Políticas y programas
  "Erasmus+": {
    definition: "Programa de la UE para la educación, formación, juventud y deporte. Permite a estudiantes, profesores y jóvenes realizar intercambios en otros países europeos.",
    category: "Programas"
  },
  "PAC": {
    definition: "Política Agrícola Común. Sistema de ayudas a los agricultores europeos que garantiza precios estables, seguridad alimentaria y desarrollo rural.",
    category: "Políticas"
  },
  "Fondos de Cohesión": {
    definition: "Dinero de la UE destinado a reducir las diferencias económicas entre regiones. Financia infraestructuras, medio ambiente y desarrollo en las zonas menos desarrolladas.",
    category: "Políticas"
  },
  "Fondos FEDER": {
    definition: "Fondo Europeo de Desarrollo Regional. Financia proyectos de infraestructuras, innovación y apoyo a empresas para reducir las desigualdades entre regiones.",
    category: "Políticas"
  },
  "NextGenerationEU": {
    definition: "Plan de recuperación de 750.000 millones de euros para superar la crisis del COVID-19. España recibe unos 140.000 millones en préstamos y subvenciones.",
    category: "Políticas"
  },
  "Mercado Único": {
    definition: "Espacio económico sin fronteras donde circulan libremente mercancías, servicios, personas y capitales. Permite a las empresas vender en 27 países sin aranceles.",
    category: "Políticas"
  },
  "Espacio Schengen": {
    definition: "Zona de 27 países europeos donde se puede viajar sin controles fronterizos. Incluye 23 países de la UE más Islandia, Liechtenstein, Noruega y Suiza.",
    category: "Políticas"
  },

  // Moneda y economía
  "Euro": {
    definition: "Moneda oficial de 20 países de la UE (la zona euro). Entró en circulación el 1 de enero de 2002, sustituyendo a monedas como la peseta española.",
    category: "Economía"
  },
  "Zona Euro": {
    definition: "Conjunto de países de la UE que han adoptado el euro como moneda. Actualmente son 20 países con más de 340 millones de habitantes.",
    category: "Economía"
  },
  "Eurozona": {
    definition: "Sinónimo de Zona Euro. Área formada por los países que comparten el euro como moneda común.",
    category: "Economía"
  },

  // Símbolos y valores
  "Bandera Europea": {
    definition: "Círculo de 12 estrellas doradas sobre fondo azul. Las estrellas representan la unidad, solidaridad y armonía entre los pueblos de Europa. El número 12 simboliza la perfección.",
    category: "Símbolos"
  },
  "Himno Europeo": {
    definition: "La 'Oda a la Alegría' de la Novena Sinfonía de Beethoven. Adoptado en 1985, expresa los ideales europeos de libertad, paz y solidaridad.",
    category: "Símbolos"
  },
  "Día de Europa": {
    definition: "Se celebra el 9 de mayo, aniversario de la Declaración Schuman de 1950. Es una jornada para celebrar la paz y la unidad en Europa.",
    category: "Símbolos"
  },
  "Lema de la UE": {
    definition: "'Unidos en la diversidad'. Significa que los europeos trabajan juntos por la paz y la prosperidad, respetando las diferentes culturas, tradiciones e idiomas.",
    category: "Símbolos"
  },

  // Figuras históricas
  "Jean Monnet": {
    definition: "Político y economista francés (1888-1979), considerado el 'padre de Europa'. Ideó el plan que llevó a la creación de la CECA y sentó las bases de la integración europea.",
    category: "Personajes"
  },
  "Robert Schuman": {
    definition: "Político francés (1886-1963) que propuso el 9 de mayo de 1950 poner bajo una autoridad común el carbón y el acero de Francia y Alemania. Su declaración inició la construcción europea.",
    category: "Personajes"
  },
  "Konrad Adenauer": {
    definition: "Primer canciller de la República Federal de Alemania (1949-1963). Impulsó la reconciliación franco-alemana y la integración de Alemania en Europa.",
    category: "Personajes"
  },
  "Alcide De Gasperi": {
    definition: "Político italiano (1881-1954), uno de los padres fundadores de la UE. Como primer ministro, orientó a Italia hacia la democracia y la integración europea.",
    category: "Personajes"
  },
  "Altiero Spinelli": {
    definition: "Político italiano (1907-1986), federalista europeo. Escribió el 'Manifiesto de Ventotene' y promovió una Europa federal y democrática.",
    category: "Personajes"
  },
  "Paul-Henri Spaak": {
    definition: "Político belga (1899-1972), uno de los padres fundadores. Presidió la Asamblea Común de la CECA y fue clave en la redacción del Tratado de Roma.",
    category: "Personajes"
  },

  // Derechos
  "Ciudadanía Europea": {
    definition: "Condición que tienen todos los nacionales de un país de la UE. Da derecho a circular libremente, votar en elecciones europeas y municipales, y recibir protección consular.",
    category: "Derechos"
  },
  "Tarjeta Sanitaria Europea": {
    definition: "Documento que permite recibir atención médica en cualquier país de la UE en las mismas condiciones que los ciudadanos locales. Es gratuita y válida en los 27 países.",
    category: "Derechos"
  },
  "Carta de Derechos Fundamentales": {
    definition: "Documento que recoge los derechos civiles, políticos, económicos y sociales de los ciudadanos europeos. Es jurídicamente vinculante desde el Tratado de Lisboa.",
    category: "Derechos"
  },
  "Libre Circulación": {
    definition: "Derecho de los ciudadanos de la UE a viajar, residir, trabajar y estudiar en cualquier país miembro sin necesidad de visado ni permiso de trabajo.",
    category: "Derechos"
  },

  // España y la UE
  "Adhesión de España": {
    definition: "España se convirtió en miembro de la CEE el 1 de enero de 1986, junto con Portugal. El Tratado de Adhesión se firmó el 12 de junio de 1985 en Madrid.",
    category: "España"
  },
  "Transición Española": {
    definition: "Período de la historia de España (1975-1982) en el que se pasó de la dictadura franquista a la democracia. Fue requisito imprescindible para entrar en la CEE.",
    category: "España"
  },
  "Felipe González": {
    definition: "Presidente del Gobierno de España (1982-1996). Bajo su mandato, España entró en la CEE (1986) y en la OTAN, modernizando el país.",
    category: "España"
  },
  "Presidencia del Consejo": {
    definition: "Cada país de la UE preside el Consejo durante 6 meses. España ha ejercido la presidencia en 1989, 1995, 2002, 2010 y 2023.",
    category: "España"
  }
};

// Componente para mostrar un término con tooltip
interface GlossaryTermProps {
  term: string;
  children?: React.ReactNode;
  className?: string;
}

export function GlossaryTerm({ term, children, className = "" }: GlossaryTermProps) {
  const glossaryEntry = glossaryTerms[term];
  
  if (!glossaryEntry) {
    return <span className={className}>{children || term}</span>;
  }

  return (
    <Tooltip delayDuration={200}>
      <TooltipTrigger asChild>
        <span className={`border-b border-dashed border-primary/50 cursor-help text-primary hover:text-primary/80 transition-colors ${className}`}>
          {children || term}
        </span>
      </TooltipTrigger>
      <TooltipContent 
        side="top" 
        className="max-w-sm p-4 bg-card border shadow-lg"
        sideOffset={5}
      >
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-primary" />
            <span className="font-bold text-primary">{term}</span>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {glossaryEntry.definition}
          </p>
          <span className="inline-block text-xs bg-secondary px-2 py-0.5 rounded">
            {glossaryEntry.category}
          </span>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

// Función para obtener todos los términos por categoría
export function getTermsByCategory(): Record<string, string[]> {
  const categories: Record<string, string[]> = {};
  
  Object.entries(glossaryTerms).forEach(([term, data]) => {
    if (!categories[data.category]) {
      categories[data.category] = [];
    }
    categories[data.category].push(term);
  });
  
  return categories;
}

// Función para buscar términos
export function searchTerms(query: string): string[] {
  const lowerQuery = query.toLowerCase();
  return Object.entries(glossaryTerms)
    .filter(([term, data]) => 
      term.toLowerCase().includes(lowerQuery) || 
      data.definition.toLowerCase().includes(lowerQuery)
    )
    .map(([term]) => term);
}

export default GlossaryTerm;
