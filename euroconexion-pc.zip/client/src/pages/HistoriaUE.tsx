import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EUFlag } from "@/components/EUStars";
import { 
  ArrowLeft, Calendar, Users, Building2, Globe, Award, 
  Lightbulb, HelpCircle, Star, Flag, Euro, BookOpen,
  ChevronRight, MapPin, Heart, Scale, Sparkles
} from "lucide-react";

// URLs de imágenes en CDN
const IMAGES = {
  foundingFathers: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/iEjiqPjjpsNnTLWK.jpg",
  treatyRome: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/iCOknVfgOjLicuaA.jpg",
  euMap: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/PJAzYOcmQSbrouNN.jpg",
  euFlag: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/FZXyNLSQfIaPTyoR.jpg",
  maastricht: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/ZjKpPfAHyQiRyNWs.jpg",
};

export default function HistoriaUE() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("origenes");

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate("/alumno")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">Historia de la UE</h1>
                <p className="text-xs text-muted-foreground">Aprende sobre la construcción europea</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-primary/10 via-eu-gold/10 to-primary/10 py-12">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Badge className="mb-4 bg-primary/20 text-primary border-primary/30">
                <BookOpen className="w-3 h-3 mr-1" />
                Contenido Educativo
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Historia de la <span className="text-primary">Unión Europea</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Descubre cómo un sueño de paz tras la Segunda Guerra Mundial se convirtió 
                en la mayor unión de países democráticos del mundo, con más de 
                <strong className="text-foreground"> 440 millones de ciudadanos</strong>.
              </p>
              <div className="flex flex-wrap gap-3">
                <Badge variant="outline" className="text-sm py-1">
                  <Flag className="w-3 h-3 mr-1" /> 27 países
                </Badge>
                <Badge variant="outline" className="text-sm py-1">
                  <Euro className="w-3 h-3 mr-1" /> Moneda común
                </Badge>
                <Badge variant="outline" className="text-sm py-1">
                  <Heart className="w-3 h-3 mr-1" /> Paz y democracia
                </Badge>
              </div>
            </div>
            <div className="relative">
              <img 
                src={IMAGES.euFlag} 
                alt="Bandera de la Unión Europea ondeando" 
                className="rounded-xl shadow-2xl w-full object-cover h-64 md:h-80"
              />
              <div className="absolute -bottom-4 -right-4 bg-card p-3 rounded-lg shadow-lg border">
                <p className="text-xs text-muted-foreground">Las 12 estrellas representan</p>
                <p className="font-bold text-primary">Unidad y solidaridad</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pregunta motivadora inicial */}
      <section className="container py-8">
        <Card className="bg-gradient-to-r from-eu-gold/20 to-primary/20 border-eu-gold/30">
          <CardContent className="py-6">
            <div className="flex items-start gap-4">
              <div className="bg-eu-gold/30 p-3 rounded-full">
                <HelpCircle className="w-6 h-6 text-eu-gold" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">🤔 ¿Sabías que...?</h3>
                <p className="text-muted-foreground">
                  Hace menos de 80 años, los países europeos estaban en guerra entre sí. 
                  Hoy, puedes viajar libremente por 27 países, estudiar en cualquier universidad 
                  europea con Erasmus y usar la misma moneda en 20 de ellos. 
                  <strong className="text-foreground"> ¿Cómo fue posible este cambio tan increíble?</strong>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Main Content with Tabs */}
      <main className="container py-8 max-w-6xl">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full mb-8 h-auto">
            <TabsTrigger value="origenes" className="flex flex-col py-3 gap-1">
              <Calendar className="w-4 h-4" />
              <span className="text-xs">Orígenes</span>
            </TabsTrigger>
            <TabsTrigger value="padres" className="flex flex-col py-3 gap-1">
              <Users className="w-4 h-4" />
              <span className="text-xs">Padres Fundadores</span>
            </TabsTrigger>
            <TabsTrigger value="tratados" className="flex flex-col py-3 gap-1">
              <Building2 className="w-4 h-4" />
              <span className="text-xs">Tratados</span>
            </TabsTrigger>
            <TabsTrigger value="ampliaciones" className="flex flex-col py-3 gap-1">
              <Globe className="w-4 h-4" />
              <span className="text-xs">Ampliaciones</span>
            </TabsTrigger>
            <TabsTrigger value="valores" className="flex flex-col py-3 gap-1">
              <Heart className="w-4 h-4" />
              <span className="text-xs">Valores</span>
            </TabsTrigger>
          </TabsList>

          {/* TAB: ORÍGENES */}
          <TabsContent value="origenes" className="space-y-8">
            <SectionHeader 
              title="Los Orígenes: Un sueño de paz" 
              subtitle="1945-1950"
              icon={<Calendar className="w-6 h-6" />}
            />
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <span className="text-2xl">💔</span> Europa en ruinas
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p>
                      La <strong>Segunda Guerra Mundial</strong> (1939-1945) dejó Europa completamente 
                      devastada. Millones de personas habían muerto, las ciudades estaban destruidas 
                      y los países se miraban con desconfianza.
                    </p>
                    <p>
                      Alemania y Francia habían sido enemigos en <strong>tres guerras</strong> en menos 
                      de 100 años. Los líderes europeos se preguntaban: 
                      <em className="text-primary"> ¿cómo evitar que esto vuelva a ocurrir?</em>
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-primary/5 border-primary/20">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                      <Lightbulb className="w-5 h-5 text-eu-gold mt-1" />
                      <div>
                        <p className="font-semibold mb-2">La idea revolucionaria</p>
                        <p className="text-muted-foreground text-sm">
                          Si los países europeos compartían sus recursos más importantes 
                          (carbón y acero, necesarios para fabricar armas), sería 
                          <strong> imposible que volvieran a hacerse la guerra</strong>.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <span className="text-2xl">📜</span> La Declaración Schuman
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p>
                      El <strong>9 de mayo de 1950</strong>, el ministro francés <strong>Robert Schuman</strong> 
                      pronunció un discurso histórico proponiendo unir la producción de carbón y acero 
                      de Francia y Alemania.
                    </p>
                    <div className="bg-secondary/50 p-4 rounded-lg border-l-4 border-primary">
                      <p className="italic text-sm">
                        "Europa no se hará de golpe ni en una construcción de conjunto: 
                        se hará mediante realizaciones concretas, creando primero una solidaridad de hecho."
                      </p>
                      <p className="text-xs font-medium mt-2 text-primary">— Robert Schuman, 1950</p>
                    </div>
                    <Badge className="bg-eu-gold/20 text-eu-gold border-eu-gold/30">
                      <Star className="w-3 h-3 mr-1" />
                      El 9 de mayo es el Día de Europa
                    </Badge>
                  </CardContent>
                </Card>
              </div>
            </div>

            <QuestionCard 
              question="¿Por qué crees que compartir el carbón y el acero era tan importante para evitar guerras?"
              hint="Piensa en para qué se usaban estos materiales en aquella época..."
            />
          </TabsContent>

          {/* TAB: PADRES FUNDADORES */}
          <TabsContent value="padres" className="space-y-8">
            <SectionHeader 
              title="Los Padres Fundadores" 
              subtitle="Los visionarios que soñaron con una Europa unida"
              icon={<Users className="w-6 h-6" />}
            />

            <div className="mb-8">
              <img 
                src={IMAGES.foundingFathers} 
                alt="Los Padres Fundadores de la Unión Europea" 
                className="w-full max-w-2xl mx-auto rounded-xl shadow-lg"
              />
              <p className="text-center text-sm text-muted-foreground mt-3">
                Los seis principales Padres Fundadores de la Unión Europea
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FounderCard 
                name="Robert Schuman"
                country="🇫🇷 Francia"
                role="Ministro de Asuntos Exteriores"
                description="Autor de la Declaración Schuman. Su propuesta de unir el carbón y el acero fue el primer paso hacia la UE."
                quote="La paz mundial no puede salvaguardarse sin esfuerzos creadores."
              />
              <FounderCard 
                name="Jean Monnet"
                country="🇫🇷 Francia"
                role="Economista y diplomático"
                description="El 'arquitecto' de Europa. Diseñó el plan de la CECA y fue su primer presidente. Las Acciones Jean Monnet llevan su nombre."
                quote="No coaligamos Estados, unimos personas."
              />
              <FounderCard 
                name="Konrad Adenauer"
                country="🇩🇪 Alemania"
                role="Canciller de Alemania"
                description="Lideró la reconciliación entre Alemania y Francia, transformando a enemigos históricos en socios."
                quote="La unidad de Europa fue un sueño de pocos. Se convirtió en esperanza de muchos."
              />
              <FounderCard 
                name="Alcide De Gasperi"
                country="🇮🇹 Italia"
                role="Primer Ministro de Italia"
                description="Impulsó la participación italiana en la integración europea desde el principio."
                quote="Nuestros países son demasiado pequeños para el mundo de hoy."
              />
              <FounderCard 
                name="Paul-Henri Spaak"
                country="🇧🇪 Bélgica"
                role="Primer Ministro de Bélgica"
                description="Presidió la conferencia que redactó los Tratados de Roma. Primer presidente del Parlamento Europeo."
                quote="No hay más que dos opciones: o hacemos Europa o la sufrimos."
              />
              <FounderCard 
                name="Joseph Bech"
                country="🇱🇺 Luxemburgo"
                role="Ministro de Asuntos Exteriores"
                description="Demostró que los países pequeños también pueden liderar grandes proyectos europeos."
                quote="La unión hace la fuerza."
              />
            </div>

            <QuestionCard 
              question="¿Qué tienen en común todos los Padres Fundadores? ¿Por qué crees que personas de países que habían sido enemigos decidieron trabajar juntos?"
              hint="Fíjate en las fechas: todos vivieron las dos guerras mundiales..."
            />
          </TabsContent>

          {/* TAB: TRATADOS */}
          <TabsContent value="tratados" className="space-y-8">
            <SectionHeader 
              title="Los Tratados Fundamentales" 
              subtitle="Los acuerdos que construyeron Europa paso a paso"
              icon={<Building2 className="w-6 h-6" />}
            />

            {/* Timeline visual de tratados */}
            <div className="relative">
              <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-primary via-eu-gold to-primary rounded-full" />
              
              <div className="space-y-12">
                <TreatyCard 
                  year="1951"
                  title="Tratado de París - CECA"
                  side="left"
                  color="bg-primary"
                  content={
                    <div className="space-y-3">
                      <p>
                        <strong>6 países</strong> (Alemania, Bélgica, Francia, Italia, Luxemburgo y Países Bajos) 
                        crean la <strong>Comunidad Europea del Carbón y del Acero</strong>.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline">🇩🇪 Alemania</Badge>
                        <Badge variant="outline">🇧🇪 Bélgica</Badge>
                        <Badge variant="outline">🇫🇷 Francia</Badge>
                        <Badge variant="outline">🇮🇹 Italia</Badge>
                        <Badge variant="outline">🇱🇺 Luxemburgo</Badge>
                        <Badge variant="outline">🇳🇱 Países Bajos</Badge>
                      </div>
                    </div>
                  }
                />

                <TreatyCard 
                  year="1957"
                  title="Tratados de Roma"
                  side="right"
                  color="bg-eu-gold"
                  image={IMAGES.treatyRome}
                  content={
                    <div className="space-y-3">
                      <p>
                        Los mismos 6 países firman dos tratados que crean:
                      </p>
                      <ul className="space-y-2">
                        <li className="flex items-start gap-2">
                          <ChevronRight className="w-4 h-4 text-primary mt-1" />
                          <span><strong>CEE</strong> (Comunidad Económica Europea): mercado común sin fronteras comerciales</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <ChevronRight className="w-4 h-4 text-primary mt-1" />
                          <span><strong>Euratom</strong>: cooperación en energía nuclear pacífica</span>
                        </li>
                      </ul>
                    </div>
                  }
                />

                <TreatyCard 
                  year="1986"
                  title="Acta Única Europea"
                  side="left"
                  color="bg-green-500"
                  content={
                    <div className="space-y-3">
                      <p>
                        Establece el objetivo de crear un <strong>mercado único</strong> para 1992: 
                        libre circulación de personas, mercancías, servicios y capitales.
                      </p>
                      <Badge className="bg-green-500/20 text-green-700 border-green-500/30">
                        Las "4 libertades" de la UE
                      </Badge>
                    </div>
                  }
                />

                <TreatyCard 
                  year="1992"
                  title="Tratado de Maastricht"
                  side="right"
                  color="bg-primary"
                  image={IMAGES.maastricht}
                  content={
                    <div className="space-y-3">
                      <p>
                        <strong>¡Nace oficialmente la Unión Europea!</strong> Este tratado histórico establece:
                      </p>
                      <ul className="space-y-2">
                        <li className="flex items-start gap-2">
                          <Euro className="w-4 h-4 text-eu-gold mt-1" />
                          <span>El camino hacia el <strong>euro</strong></span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Users className="w-4 h-4 text-primary mt-1" />
                          <span>La <strong>ciudadanía europea</strong>: todos somos ciudadanos de la UE</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Globe className="w-4 h-4 text-green-500 mt-1" />
                          <span>Política exterior y de seguridad común</span>
                        </li>
                      </ul>
                    </div>
                  }
                />

                <TreatyCard 
                  year="2007"
                  title="Tratado de Lisboa"
                  side="left"
                  color="bg-eu-gold"
                  content={
                    <div className="space-y-3">
                      <p>
                        Moderniza las instituciones europeas para funcionar con 27 países:
                      </p>
                      <ul className="space-y-2">
                        <li className="flex items-start gap-2">
                          <ChevronRight className="w-4 h-4 text-primary mt-1" />
                          <span>Más poder para el <strong>Parlamento Europeo</strong></span>
                        </li>
                        <li className="flex items-start gap-2">
                          <ChevronRight className="w-4 h-4 text-primary mt-1" />
                          <span>Crea el cargo de <strong>Presidente del Consejo Europeo</strong></span>
                        </li>
                        <li className="flex items-start gap-2">
                          <ChevronRight className="w-4 h-4 text-primary mt-1" />
                          <span>La <strong>Carta de Derechos Fundamentales</strong> se hace vinculante</span>
                        </li>
                      </ul>
                    </div>
                  }
                />
              </div>
            </div>

            <QuestionCard 
              question="¿Por qué crees que fue necesario firmar tantos tratados diferentes a lo largo de los años?"
              hint="Piensa en cómo ha ido creciendo la UE y en los nuevos retos que han surgido..."
            />
          </TabsContent>

          {/* TAB: AMPLIACIONES */}
          <TabsContent value="ampliaciones" className="space-y-8">
            <SectionHeader 
              title="Las Ampliaciones" 
              subtitle="De 6 a 27 países: el crecimiento de la familia europea"
              icon={<Globe className="w-6 h-6" />}
            />

            <div className="mb-8">
              <img 
                src={IMAGES.euMap} 
                alt="Mapa de los Estados miembros de la Unión Europea" 
                className="w-full max-w-3xl mx-auto rounded-xl shadow-lg"
              />
              <p className="text-center text-sm text-muted-foreground mt-3">
                Los 27 Estados miembros de la Unión Europea en la actualidad
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <EnlargementCard 
                year="1973"
                title="Primera ampliación"
                countries={["🇩🇰 Dinamarca", "🇮🇪 Irlanda", "🇬🇧 Reino Unido"]}
                note="Reino Unido abandonó la UE en 2020 (Brexit)"
                color="bg-blue-500"
              />
              <EnlargementCard 
                year="1981"
                title="Ampliación mediterránea I"
                countries={["🇬🇷 Grecia"]}
                note="Primera ampliación hacia el sur de Europa"
                color="bg-cyan-500"
              />
              <EnlargementCard 
                year="1986"
                title="Ampliación ibérica"
                countries={["🇪🇸 España", "🇵🇹 Portugal"]}
                note="¡España entra en la UE! Tras la dictadura, la democracia nos abre las puertas de Europa"
                color="bg-red-500"
                highlight
              />
              <EnlargementCard 
                year="1995"
                title="Ampliación nórdica"
                countries={["🇦🇹 Austria", "🇫🇮 Finlandia", "🇸🇪 Suecia"]}
                note="Países neutrales durante la Guerra Fría se unen tras su fin"
                color="bg-green-500"
              />
              <EnlargementCard 
                year="2004"
                title="La Gran Ampliación"
                countries={["🇨🇾 Chipre", "🇸🇰 Eslovaquia", "🇸🇮 Eslovenia", "🇪🇪 Estonia", "🇭🇺 Hungría", "🇱🇻 Letonia", "🇱🇹 Lituania", "🇲🇹 Malta", "🇵🇱 Polonia", "🇨🇿 Rep. Checa"]}
                note="10 países de una vez: la reunificación de Europa tras la caída del Muro de Berlín"
                color="bg-purple-500"
              />
              <EnlargementCard 
                year="2007-2013"
                title="Ampliaciones recientes"
                countries={["🇧🇬 Bulgaria (2007)", "🇷🇴 Rumanía (2007)", "🇭🇷 Croacia (2013)"]}
                note="Los Balcanes se integran progresivamente en la UE"
                color="bg-orange-500"
              />
            </div>

            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="py-6">
                <h4 className="font-bold mb-4 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Países candidatos a entrar en la UE
                </h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">🇦🇱 Albania</Badge>
                  <Badge variant="outline">🇧🇦 Bosnia y Herzegovina</Badge>
                  <Badge variant="outline">🇬🇪 Georgia</Badge>
                  <Badge variant="outline">🇲🇩 Moldavia</Badge>
                  <Badge variant="outline">🇲🇪 Montenegro</Badge>
                  <Badge variant="outline">🇲🇰 Macedonia del Norte</Badge>
                  <Badge variant="outline">🇷🇸 Serbia</Badge>
                  <Badge variant="outline">🇹🇷 Turquía</Badge>
                  <Badge variant="outline">🇺🇦 Ucrania</Badge>
                </div>
              </CardContent>
            </Card>

            <QuestionCard 
              question="¿Por qué crees que tantos países quieren entrar en la Unión Europea? ¿Qué ventajas tiene pertenecer a ella?"
              hint="Piensa en la economía, los derechos, la libertad de movimiento..."
            />
          </TabsContent>

          {/* TAB: VALORES */}
          <TabsContent value="valores" className="space-y-8">
            <SectionHeader 
              title="Los Valores de la UE" 
              subtitle="Los principios que nos unen como europeos"
              icon={<Heart className="w-6 h-6" />}
            />

            <Card className="bg-gradient-to-r from-primary/10 to-eu-gold/10 border-primary/20">
              <CardContent className="py-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold mb-2">
                    <span className="text-primary">"Unidos en la diversidad"</span>
                  </h3>
                  <p className="text-muted-foreground">
                    El lema oficial de la Unión Europea desde 2000
                  </p>
                </div>
                <p className="text-center max-w-2xl mx-auto">
                  Este lema significa que en la UE, los europeos trabajan juntos por la paz y la prosperidad, 
                  y que las muchas culturas, tradiciones y lenguas diferentes de Europa son un tesoro 
                  que enriquece a todo el continente.
                </p>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <ValueCard 
                icon={<Scale className="w-8 h-8" />}
                title="Dignidad humana"
                description="Toda persona tiene un valor único que debe ser respetado y protegido."
                color="bg-purple-500"
              />
              <ValueCard 
                icon={<Users className="w-8 h-8" />}
                title="Libertad"
                description="Libertad de movimiento, expresión, pensamiento, religión y reunión."
                color="bg-blue-500"
              />
              <ValueCard 
                icon={<Heart className="w-8 h-8" />}
                title="Democracia"
                description="Los ciudadanos eligen a sus representantes en elecciones libres."
                color="bg-red-500"
              />
              <ValueCard 
                icon={<Scale className="w-8 h-8" />}
                title="Igualdad"
                description="Todos somos iguales ante la ley, sin discriminación."
                color="bg-green-500"
              />
              <ValueCard 
                icon={<Building2 className="w-8 h-8" />}
                title="Estado de Derecho"
                description="Las leyes se aplican a todos por igual, incluidos los gobiernos."
                color="bg-orange-500"
              />
              <ValueCard 
                icon={<Sparkles className="w-8 h-8" />}
                title="Derechos Humanos"
                description="Protección de los derechos fundamentales de todas las personas."
                color="bg-pink-500"
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-eu-gold" />
                  Los símbolos de la UE
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-3 rounded-lg">
                      <Flag className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold">La bandera</h4>
                      <p className="text-sm text-muted-foreground">
                        12 estrellas doradas en círculo sobre fondo azul. El número 12 simboliza 
                        la perfección y la unidad (no el número de países).
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-eu-gold/10 p-3 rounded-lg">
                      <span className="text-2xl">🎵</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">El himno</h4>
                      <p className="text-sm text-muted-foreground">
                        "Oda a la Alegría" de Beethoven. Sin letra oficial para respetar 
                        todas las lenguas europeas.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-green-500/10 p-3 rounded-lg">
                      <Calendar className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                      <h4 className="font-semibold">El Día de Europa</h4>
                      <p className="text-sm text-muted-foreground">
                        9 de mayo, aniversario de la Declaración Schuman de 1950.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-orange-500/10 p-3 rounded-lg">
                      <Euro className="w-6 h-6 text-orange-500" />
                    </div>
                    <div>
                      <h4 className="font-semibold">El euro</h4>
                      <p className="text-sm text-muted-foreground">
                        La moneda común de 20 países de la UE desde 2002. 
                        Símbolo: € (inspirado en la letra griega épsilon).
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <QuestionCard 
              question="¿Cuál de los valores de la UE te parece más importante? ¿Por qué crees que es necesario que todos los países miembros compartan estos valores?"
              hint="Piensa en lo que pasaría si un país no respetara la democracia o los derechos humanos..."
            />
          </TabsContent>
        </Tabs>

        {/* Back Button */}
        <div className="mt-12 text-center">
          <Button 
            size="lg" 
            className="eu-btn-primary"
            onClick={() => navigate("/alumno")}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver al perfil
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card/50 py-6 mt-8">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <EUFlag size={32} />
              <div className="text-sm">
                <p className="font-semibold text-foreground">Acciones Jean Monnet</p>
                <p className="text-muted-foreground">Cofinanciado por la Unión Europea</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              IES Pérez Comendador - Plasencia | EuroconexiónPC
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Componentes auxiliares
function SectionHeader({ title, subtitle, icon }: { title: string; subtitle: string; icon: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 mb-6">
      <div className="bg-primary/10 p-3 rounded-xl">
        {icon}
      </div>
      <div>
        <h2 className="text-2xl font-bold">{title}</h2>
        <p className="text-muted-foreground">{subtitle}</p>
      </div>
    </div>
  );
}

function QuestionCard({ question, hint }: { question: string; hint: string }) {
  return (
    <Card className="bg-gradient-to-r from-eu-gold/10 to-primary/10 border-eu-gold/30">
      <CardContent className="py-6">
        <div className="flex items-start gap-4">
          <div className="bg-eu-gold/20 p-3 rounded-full shrink-0">
            <HelpCircle className="w-6 h-6 text-eu-gold" />
          </div>
          <div>
            <h4 className="font-bold text-lg mb-2">🤔 Reflexiona...</h4>
            <p className="mb-3">{question}</p>
            <p className="text-sm text-muted-foreground italic">
              <Lightbulb className="w-4 h-4 inline mr-1" />
              Pista: {hint}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function FounderCard({ name, country, role, description, quote }: { 
  name: string; country: string; role: string; description: string; quote: string 
}) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{name}</CardTitle>
          <span className="text-sm">{country}</span>
        </div>
        <p className="text-sm text-muted-foreground">{role}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm">{description}</p>
        <div className="bg-secondary/50 p-3 rounded-lg">
          <p className="text-xs italic text-muted-foreground">"{quote}"</p>
        </div>
      </CardContent>
    </Card>
  );
}

function TreatyCard({ year, title, side, color, content, image }: { 
  year: string; title: string; side: "left" | "right"; color: string; content: React.ReactNode; image?: string 
}) {
  return (
    <div className={`relative flex ${side === "right" ? "md:flex-row-reverse" : ""}`}>
      <div className="w-8 md:w-1/2" />
      <div className={`absolute left-0 md:left-1/2 -translate-x-1/2 w-8 h-8 rounded-full ${color} flex items-center justify-center text-white text-xs font-bold z-10`}>
        {year.slice(-2)}
      </div>
      <div className="w-full md:w-1/2 pl-12 md:pl-8 md:pr-8">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="pb-2">
            <Badge className={`w-fit ${color} text-white`}>{year}</Badge>
            <CardTitle className="text-lg">{title}</CardTitle>
          </CardHeader>
          <CardContent>
            {image && (
              <img src={image} alt={title} className="w-full h-32 object-cover rounded-lg mb-4" />
            )}
            {content}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function EnlargementCard({ year, title, countries, note, color, highlight }: { 
  year: string; title: string; countries: string[]; note: string; color: string; highlight?: boolean 
}) {
  return (
    <Card className={`hover:shadow-lg transition-shadow ${highlight ? "ring-2 ring-primary ring-offset-2" : ""}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <Badge className={`${color} text-white`}>{year}</Badge>
          {highlight && <Badge className="bg-eu-gold text-white">¡España!</Badge>}
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-2">
          {countries.map((country, i) => (
            <Badge key={i} variant="outline" className="text-xs">{country}</Badge>
          ))}
        </div>
        <p className="text-sm text-muted-foreground">{note}</p>
      </CardContent>
    </Card>
  );
}

function ValueCard({ icon, title, description, color }: { 
  icon: React.ReactNode; title: string; description: string; color: string 
}) {
  return (
    <Card className="hover:shadow-lg transition-shadow text-center">
      <CardContent className="pt-6">
        <div className={`${color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-white`}>
          {icon}
        </div>
        <h4 className="font-bold mb-2">{title}</h4>
        <p className="text-sm text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}
