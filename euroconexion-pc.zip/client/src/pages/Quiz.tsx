import { useState, useEffect, useMemo } from "react";
import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { EUFlag } from "@/components/EUStars";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Clock, CheckCircle2, XCircle, Trophy, Brain, ArrowRight } from "lucide-react";

// Quiz questions data
const quizData = {
  // Quiz 1 - Fácil
  "1": {
    title: "Quiz Nivel Fácil",
    difficulty: "Fácil",
    difficultyColor: "bg-green-500",
    maxScore: 150,
    questions: [
      { q: "¿Cuántos países forman actualmente la Unión Europea?", options: ["27", "25", "28", "30"], correct: 0 },
      { q: "¿En qué año se firmó el Tratado de Roma?", options: ["1945", "1992", "1957", "2002"], correct: 2 },
      { q: "¿Cuál es la capital de la Unión Europea?", options: ["París", "Berlín", "Estrasburgo", "Bruselas"], correct: 3 },
      { q: "¿En qué año entró España en la UE?", options: ["1986", "1975", "1992", "2002"], correct: 0 },
      { q: "¿Cuántas estrellas tiene la bandera de la UE?", options: ["10", "15", "12", "27"], correct: 2 },
      { q: "¿Qué día se celebra el Día de Europa?", options: ["1 de enero", "25 de marzo", "1 de noviembre", "9 de mayo"], correct: 3 },
      { q: "¿Cuál es la moneda común de la zona euro?", options: ["Euro", "Libra", "Dólar", "Franco"], correct: 0 },
      { q: "¿Qué programa permite a estudiantes estudiar en otros países de la UE?", options: ["Horizon", "Interrail", "Erasmus+", "Schengen"], correct: 2 },
      { q: "¿Cuál es el órgano legislativo de la UE elegido directamente por los ciudadanos?", options: ["Parlamento Europeo", "Consejo Europeo", "Comisión Europea", "Tribunal de Justicia"], correct: 0 },
      { q: "¿Qué país NO es miembro de la UE?", options: ["Polonia", "Portugal", "Suiza", "Dinamarca"], correct: 2 },
      { q: "¿Cuál fue el primer país en abandonar la UE?", options: ["Grecia", "Noruega", "Islandia", "Reino Unido"], correct: 3 },
      { q: "¿Qué tratado creó oficialmente la Unión Europea?", options: ["Tratado de Roma", "Tratado de Maastricht", "Tratado de Lisboa", "Tratado de París"], correct: 1 },
      { q: "¿Cuántos eurodiputados tiene España?", options: ["59", "50", "72", "96"], correct: 0 },
      { q: "¿Qué institución propone las leyes europeas?", options: ["Parlamento Europeo", "Consejo de la UE", "Tribunal de Cuentas", "Comisión Europea"], correct: 3 },
      { q: "¿Cuál es el lema de la Unión Europea?", options: ["Libertad, Igualdad, Fraternidad", "Paz y Prosperidad", "Unidos en la diversidad", "Europa Unida"], correct: 2 },
    ],
  },
  // Quiz 2 - Moderado
  "2": {
    title: "Quiz Nivel Moderado",
    difficulty: "Moderado",
    difficultyColor: "bg-yellow-500",
    maxScore: 250,
    questions: [
      { q: "¿Quién fue el autor de la Declaración Schuman?", options: ["Robert Schuman", "Jean Monnet", "Konrad Adenauer", "Alcide De Gasperi"], correct: 0 },
      { q: "¿Qué tratado estableció la libre circulación de personas?", options: ["Tratado de Roma", "Tratado de Maastricht", "Acuerdo de Schengen", "Tratado de Lisboa"], correct: 2 },
      { q: "¿En qué año entró en circulación el euro en billetes y monedas?", options: ["1999", "2002", "2000", "2004"], correct: 1 },
      { q: "¿Cuál fue el nombre original de la UE?", options: ["Comunidad Europea", "Unión de Estados Europeos", "CEE", "CECA"], correct: 3 },
      { q: "¿Qué países fundaron la CECA en 1951?", options: ["9 países", "12 países", "6 países", "15 países"], correct: 2 },
      { q: "¿Dónde tiene su sede el Banco Central Europeo?", options: ["Fráncfort", "Luxemburgo", "Bruselas", "París"], correct: 0 },
      { q: "¿Qué tratado dio más poderes al Parlamento Europeo?", options: ["Tratado de Niza", "Tratado de Ámsterdam", "Tratado de Roma", "Tratado de Lisboa"], correct: 3 },
      { q: "¿Cuántos países adoptaron el euro en 1999?", options: ["6", "15", "11", "19"], correct: 2 },
      { q: "¿Qué país presidió la UE cuando España entró?", options: ["Países Bajos", "Italia", "Luxemburgo", "Alemania"], correct: 2 },
      { q: "¿Qué es el Espacio Schengen?", options: ["Zona de libre comercio", "Zona del euro", "Zona de defensa común", "Zona sin controles fronterizos"], correct: 3 },
      { q: "¿Cuál es la función del Defensor del Pueblo Europeo?", options: ["Investigar quejas contra instituciones UE", "Defender los derechos humanos", "Proteger el medio ambiente", "Defender a los consumidores"], correct: 0 },
      { q: "¿Qué país tiene más eurodiputados?", options: ["Francia", "Italia", "España", "Alemania"], correct: 3 },
      { q: "¿Cada cuántos años se celebran las elecciones al Parlamento Europeo?", options: ["5 años", "4 años", "3 años", "6 años"], correct: 0 },
      { q: "¿Qué fondo ayudó a España a modernizar sus infraestructuras?", options: ["Fondo Social Europeo", "FEDER", "Todos los anteriores", "Fondo de Cohesión"], correct: 2 },
      { q: "¿Qué institución gestiona la política monetaria de la zona euro?", options: ["Comisión Europea", "BCE", "Eurogrupo", "FMI"], correct: 1 },
    ],
  },
  // Quiz 3 - Difícil
  "3": {
    title: "Quiz Nivel Difícil",
    difficulty: "Difícil",
    difficultyColor: "bg-red-500",
    maxScore: 400,
    questions: [
      { q: "¿En qué año se firmó el Tratado de Lisboa?", options: ["2005", "2009", "2007", "2011"], correct: 2 },
      { q: "¿Qué porcentaje del PIB de la UE representa el presupuesto comunitario aproximadamente?", options: ["5%", "10%", "15%", "1%"], correct: 3 },
      { q: "¿Cuál es el procedimiento legislativo ordinario de la UE?", options: ["Consulta", "Codecisión", "Cooperación", "Dictamen conforme"], correct: 1 },
      { q: "¿Qué artículo del TUE regula la retirada de un Estado miembro?", options: ["Artículo 50", "Artículo 48", "Artículo 7", "Artículo 352"], correct: 0 },
      { q: "¿Cuántos comisarios tiene la Comisión Europea?", options: ["15", "20", "30", "27"], correct: 3 },
      { q: "¿Qué es el 'método comunitario'?", options: ["Votación por unanimidad", "Cooperación intergubernamental", "Equilibrio institucional entre Comisión, Parlamento y Consejo", "Subsidiariedad"], correct: 2 },
      { q: "¿Cuál es la duración del mandato de un eurodiputado?", options: ["5 años", "4 años", "6 años", "7 años"], correct: 0 },
      { q: "¿Qué criterios deben cumplir los países para entrar en la zona euro?", options: ["Criterios de Copenhague", "Criterios de Lisboa", "Criterios de Dublín", "Criterios de Maastricht"], correct: 3 },
      { q: "¿Qué institución tiene el derecho exclusivo de iniciativa legislativa en la UE?", options: ["Parlamento Europeo", "Comisión Europea", "Consejo de la UE", "Consejo Europeo"], correct: 1 },
      { q: "¿Cuántos jueces tiene el Tribunal de Justicia de la UE?", options: ["15", "28", "27", "30"], correct: 2 },
      { q: "¿Qué es el Semestre Europeo?", options: ["Ciclo de coordinación de políticas económicas", "Período de sesiones del Parlamento", "Presidencia rotatoria", "Período de negociación presupuestaria"], correct: 0 },
      { q: "¿Cuál es el umbral de población para la mayoría cualificada en el Consejo?", options: ["55%", "72%", "65%", "80%"], correct: 2 },
      { q: "¿Qué tratado introdujo la ciudadanía europea?", options: ["Tratado de Maastricht", "Acta Única Europea", "Tratado de Roma", "Tratado de Ámsterdam"], correct: 0 },
      { q: "¿Cuántos fondos NextGenerationEU recibirá España aproximadamente?", options: ["70.000 millones €", "200.000 millones €", "250.000 millones €", "140.000 millones €"], correct: 3 },
      { q: "¿Qué principio establece que la UE solo actúa cuando es más eficaz que los Estados?", options: ["Proporcionalidad", "Atribución", "Subsidiariedad", "Cooperación leal"], correct: 2 },
    ],
  },
};

export default function Quiz() {
  const [, navigate] = useLocation();
  const params = useParams<{ level: string }>();
  const level = params.level || "1";
  
  const [studentId, setStudentId] = useState<number | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizFinished, setQuizFinished] = useState(false);

  const quiz = quizData[level as keyof typeof quizData];
  const activityType = `quiz${level}` as "quiz1" | "quiz2" | "quiz3";

  // Check auth
  useEffect(() => {
    const id = localStorage.getItem("studentId");
    if (!id) {
      navigate("/");
    } else {
      setStudentId(parseInt(id));
    }
  }, [navigate]);

  // Timer
  useEffect(() => {
    if (!quizStarted || quizFinished) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleNextQuestion();
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [quizStarted, quizFinished, currentQuestion]);

  const saveScore = trpc.student.saveScore.useMutation();

  const handleStartQuiz = () => {
    setQuizStarted(true);
    setAnswers(new Array(quiz.questions.length).fill(null));
  };

  const handleSelectAnswer = (index: number) => {
    if (showResult) return;
    setSelectedAnswer(index);
  };

  const handleNextQuestion = () => {
    // Save answer
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedAnswer;
    setAnswers(newAnswers);

    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setTimeLeft(30);
    } else {
      // Quiz finished
      setQuizFinished(true);
      calculateAndSaveScore(newAnswers);
    }
  };

  const handleShowResult = () => {
    setShowResult(true);
  };

  const calculateAndSaveScore = async (finalAnswers: (number | null)[]) => {
    if (!studentId) return;

    const correctCount = finalAnswers.reduce((count: number, answer, index) => {
      return count + (answer === quiz.questions[index].correct ? 1 : 0);
    }, 0);

    const score = Math.round(((correctCount ?? 0) / quiz.questions.length) * quiz.maxScore);

    await saveScore.mutateAsync({
      studentId,
      activityType,
      score,
      maxScore: quiz.maxScore,
    });

    toast.success(`¡Quiz completado! Has obtenido ${score} puntos`);
  };

  const correctCount = useMemo(() => {
    if (!quizFinished) return 0;
    return answers.reduce((count: number, answer, index) => {
      return count + (answer === quiz.questions[index].correct ? 1 : 0);
    }, 0);
  }, [answers, quiz.questions, quizFinished]);

  const score = Math.round(((correctCount ?? 0) / quiz.questions.length) * quiz.maxScore);

  if (!quiz) {
    return <div>Quiz no encontrado</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate("/alumno")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">{quiz.title}</h1>
                <Badge className={quiz.difficultyColor}>{quiz.difficulty}</Badge>
              </div>
            </div>
            {quizStarted && !quizFinished && (
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span className={`font-mono font-bold ${timeLeft <= 10 ? 'text-red-500' : 'text-foreground'}`}>
                  {timeLeft}s
                </span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8 max-w-3xl">
        {!quizStarted ? (
          // Start Screen
          <Card className="eu-card">
            <CardHeader className="text-center">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Brain className="w-10 h-10 text-primary" />
              </div>
              <CardTitle className="text-2xl">{quiz.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-secondary">
                  <p className="text-2xl font-bold text-primary">{quiz.questions.length}</p>
                  <p className="text-sm text-muted-foreground">Preguntas</p>
                </div>
                <div className="p-4 rounded-lg bg-secondary">
                  <p className="text-2xl font-bold text-eu-gold">30s</p>
                  <p className="text-sm text-muted-foreground">Por pregunta</p>
                </div>
                <div className="p-4 rounded-lg bg-secondary">
                  <p className="text-2xl font-bold text-green-500">{quiz.maxScore}</p>
                  <p className="text-sm text-muted-foreground">Puntos máx.</p>
                </div>
              </div>
              <p className="text-muted-foreground">
                Tienes 30 segundos para responder cada pregunta. ¡Buena suerte!
              </p>
              <Button size="lg" className="eu-btn-primary" onClick={handleStartQuiz}>
                Comenzar Quiz
              </Button>
            </CardContent>
          </Card>
        ) : quizFinished ? (
          // Results Screen
          <Card className="eu-card">
            <CardHeader className="text-center">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-eu-gold/20 flex items-center justify-center">
                <Trophy className="w-10 h-10 text-eu-gold" />
              </div>
              <CardTitle className="text-2xl">¡Quiz Completado!</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="p-6 rounded-xl bg-gradient-to-br from-primary/10 to-eu-gold/10">
                <p className="text-5xl font-bold text-primary mb-2">{score}</p>
                <p className="text-muted-foreground">de {quiz.maxScore} puntos</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-green-500/10">
                  <p className="text-2xl font-bold text-green-500">{correctCount}</p>
                  <p className="text-sm text-muted-foreground">Correctas</p>
                </div>
                <div className="p-4 rounded-lg bg-red-500/10">
                  <p className="text-2xl font-bold text-red-500">{quiz.questions.length - (correctCount ?? 0)}</p>
                  <p className="text-sm text-muted-foreground">Incorrectas</p>
                </div>
              </div>

              <Progress 
                value={((correctCount ?? 0) / quiz.questions.length) * 100} 
                className="h-4"
              />
              <p className="text-muted-foreground">
                {(correctCount ?? 0) >= quiz.questions.length * 0.7 
                  ? "¡Excelente trabajo! Dominas muy bien el tema."
                  : (correctCount ?? 0) >= quiz.questions.length * 0.5
                  ? "¡Buen trabajo! Sigue aprendiendo."
                  : "Sigue estudiando los contenidos para mejorar."}
              </p>

              <div className="flex gap-4 justify-center">
                <Button variant="outline" onClick={() => navigate("/alumno")}>
                  Volver al perfil
                </Button>
                {parseInt(level) < 3 && (
                  <Button 
                    className="eu-btn-primary"
                    onClick={() => navigate(`/alumno/quiz/${parseInt(level) + 1}`)}
                  >
                    Siguiente nivel
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          // Question Screen
          <div className="space-y-6">
            {/* Progress */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  Pregunta {currentQuestion + 1} de {quiz.questions.length}
                </span>
                <span className="font-medium">{Math.round(((currentQuestion + 1) / quiz.questions.length) * 100)}%</span>
              </div>
              <Progress value={((currentQuestion + 1) / quiz.questions.length) * 100} className="h-2" />
            </div>

            {/* Question Card */}
            <Card className="eu-card">
              <CardHeader>
                <CardTitle className="text-xl leading-relaxed">
                  {quiz.questions[currentQuestion].q}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {quiz.questions[currentQuestion].options.map((option, index) => {
                  const isSelected = selectedAnswer === index;
                  const isCorrect = index === quiz.questions[currentQuestion].correct;
                  const showCorrectness = showResult;

                  let className = "w-full p-4 text-left rounded-lg border-2 transition-all duration-200 ";
                  
                  if (showCorrectness) {
                    if (isCorrect) {
                      className += "border-green-500 bg-green-500/10 text-green-700";
                    } else if (isSelected && !isCorrect) {
                      className += "border-red-500 bg-red-500/10 text-red-700";
                    } else {
                      className += "border-border bg-secondary/50 text-muted-foreground";
                    }
                  } else {
                    if (isSelected) {
                      className += "border-primary bg-primary/10";
                    } else {
                      className += "border-border hover:border-primary/50 hover:bg-secondary";
                    }
                  }

                  return (
                    <button
                      key={index}
                      className={className}
                      onClick={() => handleSelectAnswer(index)}
                      disabled={showResult}
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center font-medium">
                          {String.fromCharCode(65 + index)}
                        </span>
                        <span className="flex-1">{option}</span>
                        {showCorrectness && isCorrect && (
                          <CheckCircle2 className="w-5 h-5 text-green-500" />
                        )}
                        {showCorrectness && isSelected && !isCorrect && (
                          <XCircle className="w-5 h-5 text-red-500" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => navigate("/alumno")}>
                Abandonar
              </Button>
              <div className="flex gap-2">
                {!showResult ? (
                  <Button 
                    onClick={handleShowResult}
                    disabled={selectedAnswer === null}
                  >
                    Comprobar
                  </Button>
                ) : (
                  <Button className="eu-btn-primary" onClick={handleNextQuestion}>
                    {currentQuestion < quiz.questions.length - 1 ? (
                      <>
                        Siguiente
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </>
                    ) : (
                      "Ver resultados"
                    )}
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
