import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { EUFlag } from "@/components/EUStars";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { 
  ArrowLeft, Lock, Unlock, Key, Trophy, 
  HelpCircle, Lightbulb, CheckCircle2, XCircle, DoorOpen
} from "lucide-react";

// Escape Room puzzles
const puzzles = [
  {
    id: 1,
    title: "La Puerta del Origen",
    riddle: "Soy el número de estrellas que brillan en la bandera azul de Europa. ¿Cuántas somos?",
    hint: "Mira la bandera de la UE. Las estrellas representan la unidad, no el número de países.",
    answer: "12",
    explanation: "La bandera europea tiene 12 estrellas doradas que simbolizan la unidad, solidaridad y armonía entre los pueblos de Europa.",
  },
  {
    id: 2,
    title: "El Código Fundacional",
    riddle: "En este año se firmó el Tratado de Roma, naciendo la Comunidad Económica Europea. Escribe el año.",
    hint: "Fue en la década de los 50, dos años después de que se creara la CECA.",
    answer: "1957",
    explanation: "El 25 de marzo de 1957 se firmaron los Tratados de Roma, creando la CEE y Euratom.",
  },
  {
    id: 3,
    title: "La Llave de la Unión",
    riddle: "Soy la ciudad donde tienen sede las principales instituciones europeas. Mi nombre empieza por B.",
    hint: "Es la capital de Bélgica y sede de la Comisión Europea.",
    answer: "bruselas",
    explanation: "Bruselas es considerada la capital de facto de la UE, sede de la Comisión y el Consejo.",
  },
  {
    id: 4,
    title: "El Enigma Español",
    riddle: "¿En qué año España se convirtió en miembro de pleno derecho de las Comunidades Europeas?",
    hint: "Fue durante el gobierno de Felipe González, un año después de firmar el tratado de adhesión.",
    answer: "1986",
    explanation: "España entró en la CEE el 1 de enero de 1986, junto con Portugal.",
  },
  {
    id: 5,
    title: "La Moneda Común",
    riddle: "Soy la moneda que une a millones de europeos. Mi símbolo es € y mi nombre tiene 4 letras.",
    hint: "Entró en circulación en 2002 y actualmente la usan 20 países.",
    answer: "euro",
    explanation: "El euro es la moneda oficial de la zona euro, utilizada por más de 340 millones de personas.",
  },
  {
    id: 6,
    title: "El Acertijo del Tratado",
    riddle: "Este tratado de 1992 creó oficialmente la Unión Europea. Lleva el nombre de una ciudad holandesa.",
    hint: "La ciudad está en los Países Bajos y empieza por M.",
    answer: "maastricht",
    explanation: "El Tratado de Maastricht (1992) estableció la UE, la ciudadanía europea y las bases del euro.",
  },
  {
    id: 7,
    title: "La Puerta del Conocimiento",
    riddle: "Soy el programa que permite a estudiantes europeos estudiar en otros países de la UE. Mi nombre honra a un filósofo humanista.",
    hint: "El programa lleva el nombre de Erasmo de Rotterdam.",
    answer: "erasmus",
    explanation: "El programa Erasmus+ ha permitido a millones de estudiantes estudiar en otros países europeos desde 1987.",
  },
  {
    id: 8,
    title: "El Código de los Padres",
    riddle: "Fui ministro francés y el 9 de mayo de 1950 presenté la declaración que inició la integración europea. Mi apellido empieza por S.",
    hint: "El Día de Europa se celebra en honor a mi declaración.",
    answer: "schuman",
    explanation: "Robert Schuman presentó la Declaración Schuman el 9 de mayo de 1950, considerada el inicio de la UE.",
  },
  {
    id: 9,
    title: "El Enigma Institucional",
    riddle: "Soy la única institución de la UE elegida directamente por los ciudadanos. Tengo sede en Estrasburgo.",
    hint: "Los ciudadanos votan cada 5 años para elegir a sus representantes aquí.",
    answer: "parlamento",
    explanation: "El Parlamento Europeo es la única institución de la UE elegida por sufragio universal directo.",
  },
  {
    id: 10,
    title: "La Puerta Final",
    riddle: "Soy el lema de la Unión Europea. Celebro la diversidad de culturas y lenguas. 'Unidos en la...'",
    hint: "La palabra que falta describe la variedad de culturas, lenguas y tradiciones de Europa.",
    answer: "diversidad",
    explanation: "\"Unidos en la diversidad\" es el lema de la UE, que celebra la riqueza cultural europea.",
  },
];

export default function EscapeRoom() {
  const [, navigate] = useLocation();
  const [studentId, setStudentId] = useState<number | null>(null);
  const [currentPuzzle, setCurrentPuzzle] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameFinished, setGameFinished] = useState(false);
  const [solvedPuzzles, setSolvedPuzzles] = useState<boolean[]>(new Array(puzzles.length).fill(false));
  const [hintsUsed, setHintsUsed] = useState(0);

  const saveScore = trpc.student.saveScore.useMutation();

  // Check auth
  useEffect(() => {
    const id = localStorage.getItem("studentId");
    if (!id) {
      navigate("/");
    } else {
      setStudentId(parseInt(id));
    }
  }, [navigate]);

  const normalizeAnswer = (str: string) => {
    return str.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  };

  const handleSubmit = () => {
    const puzzle = puzzles[currentPuzzle];
    const normalized = normalizeAnswer(userAnswer);
    const correct = normalizeAnswer(puzzle.answer);
    
    if (normalized === correct) {
      setIsCorrect(true);
      setShowResult(true);
      const newSolved = [...solvedPuzzles];
      newSolved[currentPuzzle] = true;
      setSolvedPuzzles(newSolved);
    } else {
      setAttempts(attempts + 1);
      setIsCorrect(false);
      setShowResult(true);
      
      if (attempts >= 2) {
        // After 3 attempts, show the answer and move on
        setTimeout(() => {
          handleNext();
        }, 3000);
      }
    }
  };

  const handleNext = () => {
    if (currentPuzzle < puzzles.length - 1) {
      setCurrentPuzzle(currentPuzzle + 1);
      setUserAnswer("");
      setAttempts(0);
      setShowHint(false);
      setShowResult(false);
      setIsCorrect(false);
    } else {
      setGameFinished(true);
      calculateAndSaveScore();
    }
  };

  const handleShowHint = () => {
    setShowHint(true);
    setHintsUsed(hintsUsed + 1);
  };

  const calculateAndSaveScore = async () => {
    if (!studentId) return;

    const solvedCount = solvedPuzzles.filter(Boolean).length;
    // Base score for solved puzzles, minus penalty for hints used
    const baseScore = (solvedCount / puzzles.length) * 500;
    const hintPenalty = hintsUsed * 10;
    const score = Math.max(0, Math.round(baseScore - hintPenalty));

    await saveScore.mutateAsync({
      studentId,
      activityType: "escaperoom",
      score,
      maxScore: 500,
    });

    toast.success(`¡Escape Room completado! Has obtenido ${score} puntos`);
  };

  const solvedCount = solvedPuzzles.filter(Boolean).length;
  const baseScore = (solvedCount / puzzles.length) * 500;
  const hintPenalty = hintsUsed * 10;
  const finalScore = Math.max(0, Math.round(baseScore - hintPenalty));

  const puzzle = puzzles[currentPuzzle];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-primary/20 to-slate-900">
      {/* Header */}
      <header className="border-b border-primary/30 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" onClick={() => navigate("/alumno")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-white">El Misterio de Europa</h1>
                <Badge variant="destructive">Escape Room</Badge>
              </div>
            </div>
            {gameStarted && !gameFinished && (
              <div className="flex items-center gap-2 text-white">
                <Key className="w-4 h-4 text-eu-gold" />
                <span className="font-mono">{solvedCount}/{puzzles.length}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8 max-w-3xl">
        {!gameStarted ? (
          // Start Screen
          <Card className="bg-slate-800/50 border-primary/30 text-white">
            <CardHeader className="text-center">
              <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary to-eu-gold flex items-center justify-center">
                <Lock className="w-12 h-12 text-white" />
              </div>
              <CardTitle className="text-3xl text-white">El Misterio de Europa</CardTitle>
              <CardDescription className="text-lg text-slate-300">
                Un escape room sobre la Unión Europea
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="p-6 rounded-xl bg-slate-700/50 border border-primary/30">
                <h3 className="font-semibold mb-4 text-eu-gold">Tu misión</h3>
                <p className="text-slate-300 mb-4">
                  Has quedado atrapado en el Parlamento Europeo después de una visita nocturna. 
                  Para escapar, debes resolver 10 acertijos sobre la Unión Europea que abrirán 
                  las puertas hacia la salida.
                </p>
                <div className="grid grid-cols-3 gap-4 mt-6">
                  <div className="p-3 rounded-lg bg-slate-600/50">
                    <p className="text-2xl font-bold text-primary">10</p>
                    <p className="text-xs text-slate-400">Acertijos</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-600/50">
                    <p className="text-2xl font-bold text-eu-gold">500</p>
                    <p className="text-xs text-slate-400">Puntos máx.</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-600/50">
                    <p className="text-2xl font-bold text-red-400">Alta</p>
                    <p className="text-xs text-slate-400">Dificultad</p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-center gap-2 text-slate-400 text-sm">
                <Lightbulb className="w-4 h-4" />
                <span>Puedes pedir pistas, pero restarán puntos</span>
              </div>

              <Button 
                size="lg" 
                className="bg-gradient-to-r from-primary to-eu-gold hover:opacity-90 text-white"
                onClick={() => setGameStarted(true)}
              >
                <DoorOpen className="w-5 h-5 mr-2" />
                Comenzar Escape Room
              </Button>
            </CardContent>
          </Card>
        ) : gameFinished ? (
          // Results Screen
          <Card className="bg-slate-800/50 border-primary/30 text-white">
            <CardHeader className="text-center">
              <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-eu-gold to-yellow-500 flex items-center justify-center">
                {solvedCount >= 7 ? (
                  <Trophy className="w-12 h-12 text-white" />
                ) : (
                  <Unlock className="w-12 h-12 text-white" />
                )}
              </div>
              <CardTitle className="text-3xl text-white">
                {solvedCount >= 7 ? "¡Has Escapado!" : "Escape Room Completado"}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="p-6 rounded-xl bg-gradient-to-br from-primary/20 to-eu-gold/20 border border-eu-gold/30">
                <p className="text-5xl font-bold text-eu-gold mb-2">{finalScore}</p>
                <p className="text-slate-300">de 500 puntos</p>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-green-500/20 border border-green-500/30">
                  <p className="text-2xl font-bold text-green-400">{solvedCount}</p>
                  <p className="text-sm text-slate-400">Resueltos</p>
                </div>
                <div className="p-4 rounded-lg bg-red-500/20 border border-red-500/30">
                  <p className="text-2xl font-bold text-red-400">{puzzles.length - solvedCount}</p>
                  <p className="text-sm text-slate-400">Fallados</p>
                </div>
                <div className="p-4 rounded-lg bg-yellow-500/20 border border-yellow-500/30">
                  <p className="text-2xl font-bold text-yellow-400">{hintsUsed}</p>
                  <p className="text-sm text-slate-400">Pistas usadas</p>
                </div>
              </div>

              <p className="text-slate-300">
                {solvedCount >= 8 
                  ? "¡Impresionante! Eres un experto en la Unión Europea."
                  : solvedCount >= 5
                  ? "¡Bien hecho! Has demostrado buenos conocimientos."
                  : "Sigue aprendiendo sobre la UE para mejorar tu puntuación."}
              </p>

              <Button 
                size="lg" 
                className="bg-gradient-to-r from-primary to-eu-gold hover:opacity-90 text-white"
                onClick={() => navigate("/alumno")}
              >
                Volver al perfil
              </Button>
            </CardContent>
          </Card>
        ) : (
          // Game Screen
          <div className="space-y-6">
            {/* Progress */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-slate-300">
                <span>Puerta {currentPuzzle + 1} de {puzzles.length}</span>
                <span className="font-medium">{Math.round(((currentPuzzle) / puzzles.length) * 100)}% completado</span>
              </div>
              <Progress value={(currentPuzzle / puzzles.length) * 100} className="h-2 bg-slate-700" />
            </div>

            {/* Puzzle Card */}
            <Card className="bg-slate-800/50 border-primary/30">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className="border-eu-gold text-eu-gold">
                    <Lock className="w-3 h-3 mr-1" />
                    {puzzle.title}
                  </Badge>
                  <Badge variant="secondary" className="bg-slate-700 text-slate-300">
                    Intentos: {attempts}/3
                  </Badge>
                </div>
                <CardTitle className="text-xl text-white flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-primary" />
                  Acertijo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Riddle */}
                <div className="p-6 rounded-xl bg-gradient-to-br from-slate-700/50 to-slate-600/50 border border-slate-600">
                  <p className="text-lg text-white leading-relaxed">{puzzle.riddle}</p>
                </div>

                {/* Hint */}
                {showHint && (
                  <div className="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                    <p className="text-sm text-yellow-300 flex items-start gap-2">
                      <Lightbulb className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>{puzzle.hint}</span>
                    </p>
                  </div>
                )}

                {/* Answer Input */}
                {!showResult ? (
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Escribe tu respuesta..."
                        value={userAnswer}
                        onChange={(e) => setUserAnswer(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && userAnswer && handleSubmit()}
                        className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                      />
                      <Button 
                        onClick={handleSubmit}
                        disabled={!userAnswer}
                        className="bg-primary hover:bg-primary/90"
                      >
                        <Key className="w-4 h-4 mr-2" />
                        Probar
                      </Button>
                    </div>
                    {!showHint && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10"
                        onClick={handleShowHint}
                      >
                        <Lightbulb className="w-4 h-4 mr-2" />
                        Pedir pista (-10 pts)
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className={`p-4 rounded-lg ${
                      isCorrect 
                        ? "bg-green-500/20 border border-green-500" 
                        : "bg-red-500/20 border border-red-500"
                    }`}>
                      <div className="flex items-center gap-2 mb-2">
                        {isCorrect ? (
                          <>
                            <CheckCircle2 className="w-5 h-5 text-green-400" />
                            <span className="font-semibold text-green-400">¡Correcto! La puerta se abre...</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-5 h-5 text-red-400" />
                            <span className="font-semibold text-red-400">
                              {attempts >= 3 ? "Sin más intentos. La respuesta era:" : "Incorrecto. Inténtalo de nuevo."}
                            </span>
                          </>
                        )}
                      </div>
                      {(isCorrect || attempts >= 3) && (
                        <p className="text-sm text-slate-300">{puzzle.explanation}</p>
                      )}
                    </div>
                    
                    {(isCorrect || attempts >= 3) && (
                      <div className="flex justify-center">
                        <Button 
                          className="bg-gradient-to-r from-primary to-eu-gold hover:opacity-90 text-white"
                          onClick={handleNext}
                        >
                          {currentPuzzle < puzzles.length - 1 ? (
                            <>
                              Siguiente puerta
                              <DoorOpen className="w-4 h-4 ml-2" />
                            </>
                          ) : (
                            "Ver resultados"
                          )}
                        </Button>
                      </div>
                    )}
                    
                    {!isCorrect && attempts < 3 && (
                      <Button 
                        variant="outline"
                        className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
                        onClick={() => {
                          setShowResult(false);
                          setUserAnswer("");
                        }}
                      >
                        Intentar de nuevo ({3 - attempts} intentos restantes)
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Door visualization */}
            <div className="flex justify-center gap-2">
              {puzzles.map((_, index) => (
                <div
                  key={index}
                  className={`w-8 h-10 rounded-t-lg border-2 transition-all ${
                    index < currentPuzzle
                      ? solvedPuzzles[index]
                        ? "bg-green-500/30 border-green-500"
                        : "bg-red-500/30 border-red-500"
                      : index === currentPuzzle
                      ? "bg-primary/30 border-primary animate-pulse"
                      : "bg-slate-700/30 border-slate-600"
                  }`}
                >
                  <div className="w-full h-full flex items-center justify-center">
                    {index < currentPuzzle ? (
                      solvedPuzzles[index] ? (
                        <Unlock className="w-3 h-3 text-green-400" />
                      ) : (
                        <XCircle className="w-3 h-3 text-red-400" />
                      )
                    ) : index === currentPuzzle ? (
                      <Lock className="w-3 h-3 text-primary" />
                    ) : (
                      <Lock className="w-3 h-3 text-slate-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
