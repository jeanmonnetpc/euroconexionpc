import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { EUFlag } from "@/components/EUStars";
import { 
  ArrowLeft, Calendar, TrendingUp, Landmark, GraduationCap, Heart, Euro,
  Lightbulb, HelpCircle, Star, Flag, Users, Building2, Plane, Train,
  ChevronRight, MapPin, Briefcase, Globe, Award, Sparkles, CheckCircle2
} from "lucide-react";

// URLs de imágenes en CDN
const IMAGES = {
  firmaAdhesion: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/GvlsEoElyJHOvIWu.jpg",
  banderasEspanaUE: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/vfyGryxnOFHVwiZO.jpg",
  aveInfraestructura: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/GHxqCxVyhgsygAoa.jpeg",
  erasmusEstudiantes: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/JkrdhDgIMtEugkuZ.jpg",
  felipeGonzalez: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663309594604/GASzrociFdoGbbfn.jpg",
};

export default function EspanaUE() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("camino");

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate("/alumno")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">España en la UE</h1>
                <p className="text-xs text-muted-foreground">40 años de integración europea</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-red-600/10 via-eu-gold/10 to-red-600/10 py-12">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Badge className="mb-4 bg-red-600 text-white">
                <Star className="w-3 h-3 mr-1" />
                40 Aniversario (1986-2026)
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                40 Años de <span className="text-red-600">España</span> en la <span className="text-primary">Unión Europea</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                El <strong>1 de enero de 1986</strong>, España se convirtió en miembro de pleno derecho 
                de las Comunidades Europeas. Cuatro décadas de <strong>transformación, modernización 
                y solidaridad</strong> que han cambiado nuestro país para siempre.
              </p>
              <div className="flex flex-wrap gap-3">
                <Badge variant="outline" className="text-sm py-1 border-red-600/30">
                  <Flag className="w-3 h-3 mr-1" /> Democracia consolidada
                </Badge>
                <Badge variant="outline" className="text-sm py-1 border-eu-gold/30">
                  <Euro className="w-3 h-3 mr-1" /> Zona euro
                </Badge>
                <Badge variant="outline" className="text-sm py-1 border-primary/30">
                  <Globe className="w-3 h-3 mr-1" /> Espacio Schengen
                </Badge>
              </div>
            </div>
            <div className="relative">
              <img 
                src={IMAGES.banderasEspanaUE} 
                alt="Banderas de España y la Unión Europea" 
                className="rounded-xl shadow-2xl w-full object-cover h-64 md:h-80"
              />
              <div className="absolute -bottom-4 -left-4 bg-card p-3 rounded-lg shadow-lg border">
                <p className="text-xs text-muted-foreground">España es el</p>
                <p className="font-bold text-red-600">4º país más grande de la UE</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Stats */}
      <section className="container py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard value="1986" label="Año de adhesión" icon={<Calendar className="w-5 h-5" />} color="text-primary" />
          <StatCard value="40" label="Años como miembro" icon={<Star className="w-5 h-5" />} color="text-eu-gold" />
          <StatCard value="+300%" label="Crecimiento del PIB" icon={<TrendingUp className="w-5 h-5" />} color="text-green-500" />
          <StatCard value="59" label="Eurodiputados españoles" icon={<Users className="w-5 h-5" />} color="text-red-600" />
        </div>
      </section>

      {/* Pregunta motivadora inicial */}
      <section className="container pb-8">
        <Card className="bg-gradient-to-r from-red-600/10 to-eu-gold/10 border-red-600/20">
          <CardContent className="py-6">
            <div className="flex items-start gap-4">
              <div className="bg-red-600/20 p-3 rounded-full">
                <HelpCircle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">🤔 ¿Sabías que...?</h3>
                <p className="text-muted-foreground">
                  Antes de 1986, los españoles necesitaban <strong>visado para viajar a Francia</strong>. 
                  Hoy puedes cruzar la frontera sin ni siquiera mostrar el DNI. La entrada en la UE 
                  transformó completamente la vida de los españoles. 
                  <strong className="text-foreground"> ¿Cómo era España antes y cómo es ahora gracias a Europa?</strong>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Main Content with Tabs */}
      <main className="container py-8 max-w-6xl">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full mb-8 h-auto">
            <TabsTrigger value="camino" className="flex flex-col py-3 gap-1">
              <Calendar className="w-4 h-4" />
              <span className="text-xs">El Camino</span>
            </TabsTrigger>
            <TabsTrigger value="economia" className="flex flex-col py-3 gap-1">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs">Economía</span>
            </TabsTrigger>
            <TabsTrigger value="infraestructuras" className="flex flex-col py-3 gap-1">
              <Train className="w-4 h-4" />
              <span className="text-xs">Infraestructuras</span>
            </TabsTrigger>
            <TabsTrigger value="erasmus" className="flex flex-col py-3 gap-1">
              <GraduationCap className="w-4 h-4" />
              <span className="text-xs">Erasmus</span>
            </TabsTrigger>
            <TabsTrigger value="derechos" className="flex flex-col py-3 gap-1">
              <Heart className="w-4 h-4" />
              <span className="text-xs">Derechos</span>
            </TabsTrigger>
          </TabsList>

          {/* TAB: EL CAMINO */}
          <TabsContent value="camino" className="space-y-8">
            <SectionHeader 
              title="El Camino hacia Europa" 
              subtitle="De la dictadura a la democracia europea"
              icon={<Calendar className="w-6 h-6" />}
            />

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <span className="text-2xl">🌑</span> España aislada
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p>
                      Durante la <strong>dictadura de Franco</strong> (1939-1975), España estuvo 
                      aislada del resto de Europa. Mientras los países europeos se unían para 
                      construir paz y prosperidad, España quedaba fuera.
                    </p>
                    <p>
                      La Comunidad Europea <strong>rechazó la solicitud de España</strong> en 1962 
                      porque no era una democracia. El mensaje era claro: 
                      <em className="text-primary"> solo los países democráticos pueden ser europeos</em>.
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-green-500/5 border-green-500/20">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                      <Lightbulb className="w-5 h-5 text-green-500 mt-1" />
                      <div>
                        <p className="font-semibold mb-2">La Transición: el cambio histórico</p>
                        <p className="text-muted-foreground text-sm">
                          Tras la muerte de Franco en 1975, España inició la <strong>Transición 
                          democrática</strong>. En solo 3 años pasamos de una dictadura a aprobar 
                          una Constitución democrática (1978) que proclamaba nuestra vocación europea.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <img 
                  src={IMAGES.firmaAdhesion} 
                  alt="Firma del Tratado de Adhesión de España a la CEE en 1985" 
                  className="w-full rounded-xl shadow-lg"
                />
                <p className="text-sm text-muted-foreground text-center">
                  Firma del Tratado de Adhesión de España en el Palacio Real de Madrid (1985)
                </p>
              </div>
            </div>

            {/* Timeline del camino */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  Cronología: El largo camino hacia Europa
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <TimelineStep year="1975" title="Muerte de Franco" description="Comienza la Transición democrática bajo el rey Juan Carlos I" done />
                  <TimelineStep year="1977" title="Solicitud de adhesión" description="El gobierno de Adolfo Suárez solicita formalmente entrar en la CEE" done />
                  <TimelineStep year="1978" title="Constitución Española" description="Se aprueba la Constitución que proclama la vocación europeísta de España" done />
                  <TimelineStep year="1979" title="Negociaciones" description="Comienzan 7 años de duras negociaciones (agricultura, pesca, industria...)" done />
                  <TimelineStep year="1982" title="Felipe González" description="El PSOE gana las elecciones. González impulsa definitivamente la adhesión" done />
                  <TimelineStep year="1985" title="Firma del Tratado" description="12 de junio: España firma el Tratado de Adhesión en el Palacio Real de Madrid" done />
                  <TimelineStep year="1986" title="¡Somos europeos!" description="1 de enero: España se convierte oficialmente en miembro de la CEE" done highlight />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="py-6">
                <div className="flex items-start gap-4">
                  <img 
                    src={IMAGES.felipeGonzalez} 
                    alt="Felipe González" 
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  <div>
                    <blockquote className="italic text-muted-foreground mb-2">
                      "Entrar en Europa era entrar en la modernidad, en la democracia consolidada, 
                      en el desarrollo económico y en la solidaridad entre pueblos."
                    </blockquote>
                    <p className="text-sm font-medium text-primary">
                      — Felipe González, Presidente del Gobierno (1982-1996)
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <QuestionCard 
              question="¿Por qué crees que la Comunidad Europea no aceptó a España mientras era una dictadura? ¿Qué nos dice esto sobre los valores de la UE?"
              hint="Recuerda los valores fundamentales de la UE que vimos en la sección anterior..."
            />
          </TabsContent>

          {/* TAB: ECONOMÍA */}
          <TabsContent value="economia" className="space-y-8">
            <SectionHeader 
              title="Transformación Económica" 
              subtitle="De país en desarrollo a economía avanzada"
              icon={<TrendingUp className="w-6 h-6" />}
            />

            {/* Comparativa antes/después */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-red-600/20">
                <CardHeader className="pb-2">
                  <Badge className="w-fit bg-red-600/20 text-red-600">1986 - Antes</Badge>
                  <CardTitle className="text-lg">España al entrar en la CEE</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <ComparisonItem label="PIB per cápita" value="72% de la media europea" negative />
                  <ComparisonItem label="Tasa de paro" value="21% de desempleo" negative />
                  <ComparisonItem label="Inflación" value="8,8% anual" negative />
                  <ComparisonItem label="Exportaciones" value="Principalmente agrícolas" negative />
                  <ComparisonItem label="Industria" value="Poco competitiva" negative />
                </CardContent>
              </Card>

              <Card className="border-green-500/20">
                <CardHeader className="pb-2">
                  <Badge className="w-fit bg-green-500/20 text-green-500">2026 - Ahora</Badge>
                  <CardTitle className="text-lg">España 40 años después</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <ComparisonItem label="PIB per cápita" value="91% de la media europea" positive />
                  <ComparisonItem label="Economía" value="14ª del mundo por PIB" positive />
                  <ComparisonItem label="Turismo" value="2º destino mundial" positive />
                  <ComparisonItem label="Exportaciones" value="Tecnología, automóviles, servicios" positive />
                  <ComparisonItem label="Empresas" value="Multinacionales españolas líderes" positive />
                </CardContent>
              </Card>
            </div>

            {/* Fondos europeos */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Euro className="w-5 h-5 text-eu-gold" />
                  Los Fondos Europeos: solidaridad en acción
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p>
                  Desde 1986, España ha recibido más de <strong className="text-primary">200.000 millones 
                  de euros</strong> en fondos europeos. Este dinero ha financiado infraestructuras, 
                  agricultura, educación, investigación y desarrollo regional.
                </p>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <FundCard 
                    title="Fondos de Cohesión"
                    amount="~80.000 M€"
                    description="Para reducir las diferencias entre regiones ricas y pobres"
                    icon={<MapPin className="w-5 h-5" />}
                  />
                  <FundCard 
                    title="Fondos Estructurales"
                    amount="~90.000 M€"
                    description="Para infraestructuras, formación y desarrollo empresarial"
                    icon={<Building2 className="w-5 h-5" />}
                  />
                  <FundCard 
                    title="PAC (Agricultura)"
                    amount="~7.000 M€/año"
                    description="Ayudas a agricultores y ganaderos españoles"
                    icon={<Sparkles className="w-5 h-5" />}
                  />
                  <FundCard 
                    title="NextGenerationEU"
                    amount="~140.000 M€"
                    description="Plan de recuperación post-COVID (2021-2026)"
                    icon={<Award className="w-5 h-5" />}
                  />
                </div>

                <Card className="bg-eu-gold/10 border-eu-gold/20">
                  <CardContent className="py-4">
                    <p className="text-sm">
                      <strong>¿Sabías que...?</strong> Gracias a los fondos europeos, Extremadura 
                      pasó de ser una de las regiones más pobres de Europa a tener autovías modernas, 
                      universidades renovadas y una agricultura competitiva. ¡Plasencia se benefició 
                      directamente de estos fondos!
                    </p>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>

            {/* El Euro */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Euro className="w-5 h-5 text-primary" />
                  El Euro: nuestra moneda común
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  El <strong>1 de enero de 2002</strong>, España adoptó el euro junto con otros 11 países. 
                  Adiós a la peseta después de 133 años.
                </p>
                <div className="grid md:grid-cols-3 gap-4">
                  <Card className="text-center bg-secondary/30">
                    <CardContent className="pt-6">
                      <p className="text-3xl mb-2">💶</p>
                      <p className="font-bold">1 € = 166,386 pesetas</p>
                      <p className="text-xs text-muted-foreground">Tipo de cambio fijo</p>
                    </CardContent>
                  </Card>
                  <Card className="text-center bg-secondary/30">
                    <CardContent className="pt-6">
                      <p className="text-3xl mb-2">🌍</p>
                      <p className="font-bold">20 países</p>
                      <p className="text-xs text-muted-foreground">Usan el euro hoy</p>
                    </CardContent>
                  </Card>
                  <Card className="text-center bg-secondary/30">
                    <CardContent className="pt-6">
                      <p className="text-3xl mb-2">👥</p>
                      <p className="font-bold">340 millones</p>
                      <p className="text-xs text-muted-foreground">De personas lo usan</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>

            <QuestionCard 
              question="¿Por qué crees que los países más ricos de Europa aceptaron dar dinero a España para que se desarrollara? ¿Qué beneficio obtienen ellos?"
              hint="Piensa en el comercio, la estabilidad y el mercado único..."
            />
          </TabsContent>

          {/* TAB: INFRAESTRUCTURAS */}
          <TabsContent value="infraestructuras" className="space-y-8">
            <SectionHeader 
              title="Modernización de Infraestructuras" 
              subtitle="De carreteras de tierra a la segunda red de AVE del mundo"
              icon={<Train className="w-6 h-6" />}
            />

            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <img 
                  src={IMAGES.aveInfraestructura} 
                  alt="Tren AVE de alta velocidad en España" 
                  className="w-full rounded-xl shadow-lg"
                />
                <p className="text-sm text-muted-foreground text-center mt-3">
                  El AVE español: símbolo de la modernización del país
                </p>
              </div>
              <div className="space-y-4">
                <Card className="bg-primary/5 border-primary/20">
                  <CardContent className="py-4">
                    <h4 className="font-bold mb-2 flex items-center gap-2">
                      <Train className="w-5 h-5 text-primary" />
                      Alta Velocidad Española (AVE)
                    </h4>
                    <p className="text-sm text-muted-foreground mb-3">
                      España tiene la <strong>segunda red de alta velocidad más extensa del mundo</strong>, 
                      solo por detrás de China.
                    </p>
                    <div className="space-y-2">
                      <ProgressStat label="Kilómetros de AVE" value={3800} max={4000} unit="km" />
                      <ProgressStat label="Ciudades conectadas" value={52} max={60} unit="" />
                      <ProgressStat label="Velocidad máxima" value={310} max={350} unit="km/h" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Infraestructuras en números */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <InfraCard 
                icon={<Train className="w-8 h-8" />}
                title="Red de AVE"
                before="0 km (1986)"
                after="3.800 km (2026)"
                color="bg-primary"
              />
              <InfraCard 
                icon={<Landmark className="w-8 h-8" />}
                title="Autovías"
                before="2.000 km"
                after="17.500 km"
                color="bg-green-500"
              />
              <InfraCard 
                icon={<Plane className="w-8 h-8" />}
                title="Pasajeros aéreos"
                before="25 millones/año"
                after="275 millones/año"
                color="bg-blue-500"
              />
              <InfraCard 
                icon={<Globe className="w-8 h-8" />}
                title="Turistas"
                before="25 millones/año"
                after="85 millones/año"
                color="bg-eu-gold"
              />
            </div>

            {/* Ejemplos concretos */}
            <Card>
              <CardHeader>
                <CardTitle>Proyectos financiados por la UE que conoces</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <ProjectCard 
                    title="Autovía A-66 (Ruta de la Plata)"
                    description="Conecta Sevilla con Gijón pasando por Extremadura. Antes era una carretera nacional con muchos accidentes."
                    funded="Fondos FEDER"
                  />
                  <ProjectCard 
                    title="AVE Madrid-Sevilla (1992)"
                    description="El primer tren de alta velocidad de España, inaugurado para la Expo de Sevilla."
                    funded="Fondos de Cohesión"
                  />
                  <ProjectCard 
                    title="Depuradoras de agua"
                    description="España pasó de depurar el 20% de sus aguas residuales al 95% gracias a fondos europeos."
                    funded="Fondos de Cohesión"
                  />
                  <ProjectCard 
                    title="Universidades y centros de investigación"
                    description="Modernización de campus, laboratorios y equipamiento científico en toda España."
                    funded="Fondos FEDER"
                  />
                </div>
              </CardContent>
            </Card>

            <QuestionCard 
              question="¿Conoces alguna infraestructura de tu ciudad o región que haya sido financiada con fondos europeos? Busca las placas azules con las estrellas de la UE."
              hint="Fíjate en carreteras, edificios públicos, parques, instalaciones deportivas..."
            />
          </TabsContent>

          {/* TAB: ERASMUS */}
          <TabsContent value="erasmus" className="space-y-8">
            <SectionHeader 
              title="Erasmus: La generación europea" 
              subtitle="Más de un millón de españoles han estudiado en Europa"
              icon={<GraduationCap className="w-6 h-6" />}
            />

            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <Card className="bg-primary/5 border-primary/20">
                  <CardContent className="py-6">
                    <h3 className="text-2xl font-bold mb-2">
                      <span className="text-primary">Erasmus+</span>
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      El programa de intercambio educativo más exitoso del mundo. Desde 1987, 
                      ha permitido a más de <strong>12 millones de europeos</strong> estudiar, 
                      formarse o hacer voluntariado en otro país.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">🎓 Universidad</Badge>
                      <Badge variant="outline">📚 Formación Profesional</Badge>
                      <Badge variant="outline">🏫 Secundaria</Badge>
                      <Badge variant="outline">🤝 Voluntariado</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div>
                <img 
                  src={IMAGES.erasmusEstudiantes} 
                  alt="Estudiantes Erasmus en España" 
                  className="w-full rounded-xl shadow-lg"
                />
                <p className="text-sm text-muted-foreground text-center mt-3">
                  Estudiantes Erasmus disfrutando de su experiencia en España
                </p>
              </div>
            </div>

            {/* España en Erasmus */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-eu-gold" />
                  España: líder en Erasmus
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-primary mb-2">+1.000.000</p>
                    <p className="text-muted-foreground">Estudiantes españoles han sido Erasmus</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-eu-gold mb-2">#1</p>
                    <p className="text-muted-foreground">Destino favorito de los Erasmus europeos</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-green-500 mb-2">+50.000</p>
                    <p className="text-muted-foreground">Estudiantes extranjeros recibimos cada año</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Destinos favoritos */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">🇪🇸 ¿Dónde van los españoles?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <DestinationBar country="🇮🇹 Italia" percentage={22} />
                    <DestinationBar country="🇬🇧 Reino Unido" percentage={18} />
                    <DestinationBar country="🇫🇷 Francia" percentage={15} />
                    <DestinationBar country="🇩🇪 Alemania" percentage={12} />
                    <DestinationBar country="🇵🇱 Polonia" percentage={8} />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">🌍 ¿De dónde vienen a España?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <DestinationBar country="🇮🇹 Italia" percentage={25} />
                    <DestinationBar country="🇫🇷 Francia" percentage={18} />
                    <DestinationBar country="🇩🇪 Alemania" percentage={14} />
                    <DestinationBar country="🇵🇱 Polonia" percentage={10} />
                    <DestinationBar country="🇳🇱 Países Bajos" percentage={7} />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Beneficios del Erasmus */}
            <Card className="bg-gradient-to-r from-primary/5 to-eu-gold/5">
              <CardHeader>
                <CardTitle>¿Por qué hacer un Erasmus?</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <BenefitCard 
                    icon="🌍"
                    title="Idiomas"
                    description="Aprenderás o mejorarás otro idioma de forma natural"
                  />
                  <BenefitCard 
                    icon="👥"
                    title="Amigos internacionales"
                    description="Conocerás gente de toda Europa que serán amigos para siempre"
                  />
                  <BenefitCard 
                    icon="💼"
                    title="Empleabilidad"
                    description="Los Erasmus tienen un 23% menos de paro que los demás"
                  />
                  <BenefitCard 
                    icon="🧠"
                    title="Madurez"
                    description="Aprenderás a ser independiente y a adaptarte a nuevas situaciones"
                  />
                </div>
              </CardContent>
            </Card>

            <QuestionCard 
              question="Si pudieras hacer un Erasmus, ¿a qué país te gustaría ir? ¿Qué te gustaría aprender o experimentar allí?"
              hint="Piensa en el idioma, la cultura, las universidades, la gastronomía..."
            />
          </TabsContent>

          {/* TAB: DERECHOS */}
          <TabsContent value="derechos" className="space-y-8">
            <SectionHeader 
              title="Derechos y Ciudadanía Europea" 
              subtitle="Lo que significa ser ciudadano de la Unión Europea"
              icon={<Heart className="w-6 h-6" />}
            />

            <Card className="bg-gradient-to-r from-primary/10 to-red-600/10 border-primary/20">
              <CardContent className="py-8 text-center">
                <h3 className="text-2xl font-bold mb-4">
                  Eres <span className="text-red-600">español</span> y también <span className="text-primary">europeo</span>
                </h3>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Desde el Tratado de Maastricht (1992), todos los ciudadanos de los países de la UE 
                  somos también <strong>ciudadanos europeos</strong>. Esto nos da derechos adicionales 
                  que no tienen los ciudadanos de otros países.
                </p>
              </CardContent>
            </Card>

            {/* Derechos principales */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <RightCard 
                icon={<Globe className="w-8 h-8" />}
                title="Libre circulación"
                description="Puedes viajar, vivir, trabajar y estudiar en cualquiera de los 27 países de la UE sin necesidad de visado ni permiso de trabajo."
                example="Un español puede mudarse a Alemania mañana y empezar a trabajar legalmente."
                color="bg-primary"
              />
              <RightCard 
                icon={<Building2 className="w-8 h-8" />}
                title="Votar en Europa"
                description="Puedes votar en las elecciones al Parlamento Europeo y en las elecciones municipales del país de la UE donde residas."
                example="Un español que vive en Francia puede votar en las elecciones municipales francesas."
                color="bg-eu-gold"
              />
              <RightCard 
                icon={<Users className="w-8 h-8" />}
                title="Protección consular"
                description="Si estás en un país fuera de la UE donde España no tiene embajada, cualquier embajada de la UE debe ayudarte."
                example="Un español en Maldivas puede pedir ayuda en la embajada alemana o francesa."
                color="bg-green-500"
              />
              <RightCard 
                icon={<Heart className="w-8 h-8" />}
                title="Tarjeta Sanitaria Europea"
                description="Con la TSE puedes recibir atención médica en cualquier país de la UE en las mismas condiciones que los ciudadanos locales."
                example="Si te pones enfermo en Italia de vacaciones, te atienden gratis con tu TSE."
                color="bg-red-500"
              />
              <RightCard 
                icon={<Briefcase className="w-8 h-8" />}
                title="Reconocimiento de títulos"
                description="Tu título universitario o de FP es válido en toda la UE. Puedes ejercer tu profesión en cualquier país miembro."
                example="Un médico español puede trabajar en un hospital de Portugal sin revalidar su título."
                color="bg-purple-500"
              />
              <RightCard 
                icon={<Award className="w-8 h-8" />}
                title="Protección de derechos"
                description="La Carta de Derechos Fundamentales de la UE te protege. Puedes denunciar ante el Tribunal Europeo si se vulneran tus derechos."
                example="Si una ley española vulnera tus derechos europeos, puedes recurrir a Luxemburgo."
                color="bg-orange-500"
              />
            </div>

            {/* Espacio Schengen */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  El Espacio Schengen: Europa sin fronteras
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  España forma parte del <strong>Espacio Schengen</strong> desde 1995. Esto significa 
                  que puedes viajar a 26 países europeos <strong>sin mostrar el pasaporte</strong> ni 
                  pasar controles fronterizos.
                </p>
                <div className="bg-secondary/30 p-4 rounded-lg">
                  <p className="font-semibold mb-2">Países Schengen:</p>
                  <p className="text-sm text-muted-foreground">
                    Alemania, Austria, Bélgica, Croacia, Dinamarca, Eslovaquia, Eslovenia, España, 
                    Estonia, Finlandia, Francia, Grecia, Hungría, Islandia, Italia, Letonia, 
                    Liechtenstein, Lituania, Luxemburgo, Malta, Noruega, Países Bajos, Polonia, 
                    Portugal, República Checa, Suecia y Suiza.
                  </p>
                </div>
                <Card className="bg-eu-gold/10 border-eu-gold/20">
                  <CardContent className="py-4">
                    <p className="text-sm">
                      <strong>Curiosidad:</strong> Antes de Schengen, cruzar de España a Francia 
                      podía llevar horas de cola en la frontera. Hoy, ni siquiera te das cuenta 
                      de que has cambiado de país.
                    </p>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>

            <QuestionCard 
              question="¿Cuál de estos derechos te parece más importante? ¿Crees que los jóvenes de hoy valoramos suficiente poder viajar y trabajar libremente por Europa?"
              hint="Pregunta a tus padres o abuelos cómo era viajar a Francia antes de 1986..."
            />
          </TabsContent>
        </Tabs>

        {/* Back Button */}
        <div className="mt-12 text-center">
          <Button 
            size="lg" 
            className="eu-btn-primary"
            onClick={() => navigate("/alumno")}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver al perfil
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card/50 py-6 mt-8">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <EUFlag size={32} />
              <div className="text-sm">
                <p className="font-semibold text-foreground">Acciones Jean Monnet</p>
                <p className="text-muted-foreground">Cofinanciado por la Unión Europea</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              IES Pérez Comendador - Plasencia | EuroconexiónPC
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Componentes auxiliares
function SectionHeader({ title, subtitle, icon }: { title: string; subtitle: string; icon: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 mb-6">
      <div className="bg-primary/10 p-3 rounded-xl">
        {icon}
      </div>
      <div>
        <h2 className="text-2xl font-bold">{title}</h2>
        <p className="text-muted-foreground">{subtitle}</p>
      </div>
    </div>
  );
}

function StatCard({ value, label, icon, color }: { value: string; label: string; icon: React.ReactNode; color: string }) {
  return (
    <Card className="text-center hover:shadow-lg transition-shadow">
      <CardContent className="pt-6">
        <div className={`${color} mb-2`}>{icon}</div>
        <p className={`text-3xl font-bold ${color}`}>{value}</p>
        <p className="text-sm text-muted-foreground">{label}</p>
      </CardContent>
    </Card>
  );
}

function QuestionCard({ question, hint }: { question: string; hint: string }) {
  return (
    <Card className="bg-gradient-to-r from-red-600/10 to-eu-gold/10 border-red-600/20">
      <CardContent className="py-6">
        <div className="flex items-start gap-4">
          <div className="bg-red-600/20 p-3 rounded-full shrink-0">
            <HelpCircle className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h4 className="font-bold text-lg mb-2">🤔 Reflexiona...</h4>
            <p className="mb-3">{question}</p>
            <p className="text-sm text-muted-foreground italic">
              <Lightbulb className="w-4 h-4 inline mr-1" />
              Pista: {hint}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function TimelineStep({ year, title, description, done, highlight }: { 
  year: string; title: string; description: string; done?: boolean; highlight?: boolean 
}) {
  return (
    <div className={`flex items-start gap-4 ${highlight ? "bg-green-500/10 -mx-4 px-4 py-2 rounded-lg" : ""}`}>
      <div className={`w-16 shrink-0 text-center ${highlight ? "font-bold text-green-500" : ""}`}>
        <Badge variant={highlight ? "default" : "outline"} className={highlight ? "bg-green-500" : ""}>
          {year}
        </Badge>
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          {done && <CheckCircle2 className={`w-4 h-4 ${highlight ? "text-green-500" : "text-primary"}`} />}
          <p className={`font-semibold ${highlight ? "text-green-500" : ""}`}>{title}</p>
        </div>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

function ComparisonItem({ label, value, positive, negative }: { 
  label: string; value: string; positive?: boolean; negative?: boolean 
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm">{label}</span>
      <Badge variant="outline" className={positive ? "border-green-500 text-green-500" : negative ? "border-red-600 text-red-600" : ""}>
        {value}
      </Badge>
    </div>
  );
}

function FundCard({ title, amount, description, icon }: { 
  title: string; amount: string; description: string; icon: React.ReactNode 
}) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="pt-4">
        <div className="flex items-start gap-3">
          <div className="bg-primary/10 p-2 rounded-lg text-primary">{icon}</div>
          <div>
            <p className="font-semibold">{title}</p>
            <p className="text-lg font-bold text-primary">{amount}</p>
            <p className="text-xs text-muted-foreground">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ProgressStat({ label, value, max, unit }: { label: string; value: number; max: number; unit: string }) {
  return (
    <div>
      <div className="flex justify-between text-sm mb-1">
        <span>{label}</span>
        <span className="font-bold">{value.toLocaleString()} {unit}</span>
      </div>
      <Progress value={(value / max) * 100} className="h-2" />
    </div>
  );
}

function InfraCard({ icon, title, before, after, color }: { 
  icon: React.ReactNode; title: string; before: string; after: string; color: string 
}) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="pt-6 text-center">
        <div className={`${color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-white`}>
          {icon}
        </div>
        <h4 className="font-bold mb-2">{title}</h4>
        <p className="text-xs text-red-600 line-through">{before}</p>
        <p className="text-sm font-bold text-green-500">{after}</p>
      </CardContent>
    </Card>
  );
}

function ProjectCard({ title, description, funded }: { title: string; description: string; funded: string }) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="pt-4">
        <div className="flex items-start gap-2 mb-2">
          <CheckCircle2 className="w-4 h-4 text-green-500 mt-1 shrink-0" />
          <p className="font-semibold">{title}</p>
        </div>
        <p className="text-sm text-muted-foreground mb-2">{description}</p>
        <Badge variant="outline" className="text-xs">{funded}</Badge>
      </CardContent>
    </Card>
  );
}

function DestinationBar({ country, percentage }: { country: string; percentage: number }) {
  return (
    <div>
      <div className="flex justify-between text-sm mb-1">
        <span>{country}</span>
        <span className="font-bold">{percentage}%</span>
      </div>
      <Progress value={percentage} className="h-2" />
    </div>
  );
}

function BenefitCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <Card className="text-center hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <p className="text-3xl mb-2">{icon}</p>
        <h4 className="font-bold mb-1">{title}</h4>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}

function RightCard({ icon, title, description, example, color }: { 
  icon: React.ReactNode; title: string; description: string; example: string; color: string 
}) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="pt-6">
        <div className={`${color} w-14 h-14 rounded-full flex items-center justify-center mb-4 text-white`}>
          {icon}
        </div>
        <h4 className="font-bold mb-2">{title}</h4>
        <p className="text-sm text-muted-foreground mb-3">{description}</p>
        <div className="bg-secondary/30 p-2 rounded text-xs">
          <strong>Ejemplo:</strong> {example}
        </div>
      </CardContent>
    </Card>
  );
}
