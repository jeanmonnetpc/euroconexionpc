import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { EUFlag } from "@/components/EUStars";
import { trpc } from "@/lib/trpc";
import { 
  BookOpen, Gamepad2, Trophy, LogOut, 
  History, Flag, Brain, Users, Lock, 
  CheckCircle2, Play, Star, BookMarked
} from "lucide-react";

export default function Student() {
  const [, navigate] = useLocation();
  const [studentId, setStudentId] = useState<number | null>(null);
  const [studentName, setStudentName] = useState("");
  
  // Check auth
  useEffect(() => {
    const id = localStorage.getItem("studentId");
    const name = localStorage.getItem("studentName");
    if (!id) {
      navigate("/");
    } else {
      setStudentId(parseInt(id));
      setStudentName(name || "");
    }
  }, [navigate]);

  // tRPC queries
  const progress = trpc.student.getProgress.useQuery(
    { studentId: studentId! },
    { enabled: !!studentId }
  );

  const handleLogout = () => {
    localStorage.removeItem("studentId");
    localStorage.removeItem("studentName");
    navigate("/");
  };

  if (!studentId) return null;

  const totalActivities = 5;
  const completedActivities = [
    progress.data?.quiz1Completed,
    progress.data?.quiz2Completed,
    progress.data?.quiz3Completed,
    progress.data?.roleplayCompleted,
    progress.data?.escaperoomCompleted,
  ].filter(Boolean).length;

  const progressPercentage = (completedActivities / totalActivities) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">EuroconexiónPC</h1>
                <p className="text-xs text-muted-foreground">Área de Alumno</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10">
                <Trophy className="w-4 h-4 text-eu-gold" />
                <span className="font-bold text-primary">{progress.data?.totalPoints || 0}</span>
                <span className="text-xs text-muted-foreground">pts</span>
              </div>
              <span className="text-sm text-muted-foreground hidden md:inline">
                Hola, <span className="font-medium text-foreground">{studentName}</span>
              </span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Progress Overview */}
        <Card className="mb-8 eu-card">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <Star className="w-8 h-8 text-eu-gold" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">¡Bienvenido/a, {studentName}!</h2>
                  <p className="text-muted-foreground">
                    Has completado {completedActivities} de {totalActivities} actividades
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-3xl font-bold text-primary">{progress.data?.totalPoints || 0}</p>
                  <p className="text-xs text-muted-foreground">puntos totales</p>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Progreso general</span>
                <span className="font-medium">{Math.round(progressPercentage)}%</span>
              </div>
              <Progress value={progressPercentage} className="h-3" />
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="contenidos" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
            <TabsTrigger value="contenidos" className="gap-2">
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">Contenidos</span>
            </TabsTrigger>
            <TabsTrigger value="actividades" className="gap-2">
              <Gamepad2 className="w-4 h-4" />
              <span className="hidden sm:inline">Actividades</span>
            </TabsTrigger>
            <TabsTrigger value="progreso" className="gap-2">
              <Trophy className="w-4 h-4" />
              <span className="hidden sm:inline">Mi Progreso</span>
            </TabsTrigger>
          </TabsList>

          {/* Contenidos Tab */}
          <TabsContent value="contenidos" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Historia de la UE */}
              <Card className="eu-card hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <History className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle>Historia de la Unión Europea</CardTitle>
                  <CardDescription>
                    Descubre cómo nació y evolucionó la Unión Europea desde sus orígenes hasta hoy
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full eu-btn-primary"
                    onClick={() => navigate("/alumno/historia-ue")}
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    Explorar contenido
                  </Button>
                </CardContent>
              </Card>

              {/* 40 años de España */}
              <Card className="eu-card hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center mb-4">
                    <Flag className="w-6 h-6 text-accent-foreground" />
                  </div>
                  <CardTitle>40 Años de España en la UE</CardTitle>
                  <CardDescription>
                    Conoce el camino de España como Estado miembro y los beneficios de la integración europea
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full eu-btn-gold"
                    onClick={() => navigate("/alumno/espana-ue")}
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    Explorar contenido
                  </Button>
                </CardContent>
              </Card>

              {/* Glosario */}
              <Card className="eu-card hover:shadow-xl transition-all duration-300 border-dashed border-2 border-primary/30">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center mb-4">
                    <BookMarked className="w-6 h-6 text-green-600" />
                  </div>
                  <CardTitle>Glosario Europeo</CardTitle>
                  <CardDescription>
                    Consulta las definiciones de los términos clave sobre la Unión Europea
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="outline"
                    className="w-full border-green-500 text-green-600 hover:bg-green-500/10"
                    onClick={() => navigate("/alumno/glosario")}
                  >
                    <BookMarked className="w-4 h-4 mr-2" />
                    Consultar glosario
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Actividades Tab */}
          <TabsContent value="actividades" className="space-y-6">
            {/* Quizzes */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Brain className="w-5 h-5 text-primary" />
                Desafíos Quiz
              </h3>
              <div className="grid md:grid-cols-3 gap-4">
                <ActivityCard
                  title="Quiz Nivel Fácil"
                  description="15 preguntas básicas sobre la UE"
                  difficulty="Fácil"
                  difficultyColor="bg-green-500"
                  points={150}
                  completed={progress.data?.quiz1Completed}
                  onClick={() => navigate("/alumno/quiz/1")}
                />
                <ActivityCard
                  title="Quiz Nivel Moderado"
                  description="15 preguntas de dificultad media"
                  difficulty="Moderado"
                  difficultyColor="bg-yellow-500"
                  points={250}
                  completed={progress.data?.quiz2Completed}
                  locked={!progress.data?.quiz1Completed}
                  onClick={() => navigate("/alumno/quiz/2")}
                />
                <ActivityCard
                  title="Quiz Nivel Difícil"
                  description="15 preguntas avanzadas"
                  difficulty="Difícil"
                  difficultyColor="bg-red-500"
                  points={400}
                  completed={progress.data?.quiz3Completed}
                  locked={!progress.data?.quiz2Completed}
                  onClick={() => navigate("/alumno/quiz/3")}
                />
              </div>
            </div>

            {/* Juego de Rol */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Juego de Rol
              </h3>
              <Card className="eu-card">
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                        <Users className="w-8 h-8 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-lg">Eurodiputado por un día</h4>
                        <p className="text-muted-foreground text-sm">
                          Simula ser eurodiputado y vota leyes y reglamentos de la UE
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="secondary">Interactivo</Badge>
                          <Badge variant="outline" className="text-eu-gold border-eu-gold">
                            +300 pts
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {progress.data?.roleplayCompleted ? (
                        <Badge className="bg-green-500">
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Completado
                        </Badge>
                      ) : (
                        <Button 
                          className="eu-btn-primary"
                          onClick={() => navigate("/alumno/roleplay")}
                        >
                          <Play className="w-4 h-4 mr-2" />
                          Jugar
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Escape Room */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Lock className="w-5 h-5 text-primary" />
                Escape Room
              </h3>
              <Card className="eu-card border-2 border-primary/20">
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center">
                        <Lock className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-lg">El Misterio de Europa</h4>
                        <p className="text-muted-foreground text-sm">
                          10 acertijos desafiantes que debes resolver para escapar
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="destructive">Dificultad Alta</Badge>
                          <Badge variant="outline" className="text-eu-gold border-eu-gold">
                            +500 pts
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {progress.data?.escaperoomCompleted ? (
                        <Badge className="bg-green-500">
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Completado
                        </Badge>
                      ) : (
                        <Button 
                          className="eu-btn-primary"
                          onClick={() => navigate("/alumno/escaperoom")}
                        >
                          <Play className="w-4 h-4 mr-2" />
                          Comenzar
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Progreso Tab */}
          <TabsContent value="progreso">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-eu-gold" />
                  Mi Progreso
                </CardTitle>
                <CardDescription>
                  Resumen de tus logros y actividades completadas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <ProgressItem
                    title="Quiz Nivel Fácil"
                    completed={progress.data?.quiz1Completed}
                    points={150}
                  />
                  <ProgressItem
                    title="Quiz Nivel Moderado"
                    completed={progress.data?.quiz2Completed}
                    points={250}
                  />
                  <ProgressItem
                    title="Quiz Nivel Difícil"
                    completed={progress.data?.quiz3Completed}
                    points={400}
                  />
                  <ProgressItem
                    title="Juego de Rol: Eurodiputado"
                    completed={progress.data?.roleplayCompleted}
                    points={300}
                  />
                  <ProgressItem
                    title="Escape Room"
                    completed={progress.data?.escaperoomCompleted}
                    points={500}
                  />
                </div>

                <div className="mt-8 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">Puntuación Total</p>
                      <p className="text-sm text-muted-foreground">
                        Máximo posible: 1600 puntos
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-4xl font-bold text-primary">
                        {progress.data?.totalPoints || 0}
                      </p>
                      <p className="text-sm text-muted-foreground">puntos</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card/50 py-6 mt-8">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <EUFlag size={32} />
              <div className="text-sm">
                <p className="font-semibold text-foreground">Acciones Jean Monnet</p>
                <p className="text-muted-foreground">Cofinanciado por la Unión Europea</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              IES Pérez Comendador - Plasencia
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Activity Card Component
function ActivityCard({
  title,
  description,
  difficulty,
  difficultyColor,
  points,
  completed,
  locked,
  onClick,
}: {
  title: string;
  description: string;
  difficulty: string;
  difficultyColor: string;
  points: number;
  completed?: boolean | null;
  locked?: boolean;
  onClick: () => void;
}) {
  return (
    <Card className={`eu-card transition-all duration-300 ${locked ? 'opacity-60' : 'hover:shadow-xl hover:-translate-y-1'}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between mb-2">
          <Badge className={difficultyColor}>{difficulty}</Badge>
          <Badge variant="outline" className="text-eu-gold border-eu-gold">
            +{points} pts
          </Badge>
        </div>
        <CardTitle className="text-base">{title}</CardTitle>
        <CardDescription className="text-sm">{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {completed ? (
          <Badge className="w-full justify-center py-2 bg-green-500">
            <CheckCircle2 className="w-4 h-4 mr-2" />
            Completado
          </Badge>
        ) : locked ? (
          <Button disabled className="w-full">
            <Lock className="w-4 h-4 mr-2" />
            Bloqueado
          </Button>
        ) : (
          <Button className="w-full" onClick={onClick}>
            <Play className="w-4 h-4 mr-2" />
            Comenzar
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

// Progress Item Component
function ProgressItem({
  title,
  completed,
  points,
}: {
  title: string;
  completed?: boolean | null;
  points: number;
}) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
      <div className="flex items-center gap-3">
        {completed ? (
          <CheckCircle2 className="w-5 h-5 text-green-500" />
        ) : (
          <div className="w-5 h-5 rounded-full border-2 border-muted-foreground" />
        )}
        <span className={completed ? "text-foreground" : "text-muted-foreground"}>
          {title}
        </span>
      </div>
      <Badge variant={completed ? "default" : "outline"}>
        {completed ? `+${points}` : `${points} pts`}
      </Badge>
    </div>
  );
}
