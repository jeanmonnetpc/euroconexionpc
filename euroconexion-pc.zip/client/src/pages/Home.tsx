import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EUFlag } from "@/components/EUStars";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { GraduationCap, Users, Shield, BookOpen, Trophy, Gamepad2 } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();
  const [showStudentDialog, setShowStudentDialog] = useState(false);
  const [showTeacherDialog, setShowTeacherDialog] = useState(false);
  const [showAdminDialog, setShowAdminDialog] = useState(false);
  const [showStudentRegister, setShowStudentRegister] = useState(false);
  
  // Student form state
  const [studentName, setStudentName] = useState("");
  const [classCode, setClassCode] = useState("");
  
  // Teacher form state
  const [teacherEmail, setTeacherEmail] = useState("");
  const [teacherPassword, setTeacherPassword] = useState("");
  
  // Admin form state
  const [adminPassword, setAdminPassword] = useState("");
  const [isAdminSetup, setIsAdminSetup] = useState(false);
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [confirmAdminPassword, setConfirmAdminPassword] = useState("");
  
  // tRPC mutations and queries
  const checkStudentExists = trpc.student.checkExists.useQuery(
    { name: studentName, classCode },
    { enabled: false }
  );
  
  const registerStudent = trpc.student.register.useMutation();
  const teacherLogin = trpc.teacher.login.useMutation();
  const adminLogin = trpc.admin.login.useMutation();
  const adminExists = trpc.admin.exists.useQuery();
  const adminSetup = trpc.admin.setup.useMutation();

  const handleStudentAccess = async () => {
    if (!studentName.trim() || !classCode.trim()) {
      toast.error("Por favor, introduce tu nombre y el código de clase");
      return;
    }
    
    const result = await checkStudentExists.refetch();
    
    if (!result.data?.classExists) {
      toast.error("El código de clase no existe");
      return;
    }
    
    if (result.data?.exists && result.data?.student) {
      // Student exists, go to profile
      localStorage.setItem("studentId", result.data.student.id.toString());
      localStorage.setItem("studentName", result.data.student.name);
      navigate("/alumno");
    } else {
      // Show registration form
      setShowStudentRegister(true);
    }
  };

  const handleStudentRegister = async () => {
    if (!studentName.trim() || !classCode.trim()) {
      toast.error("Por favor, completa todos los campos");
      return;
    }
    
    const result = await registerStudent.mutateAsync({ name: studentName, classCode });
    
    if (result.success && result.student) {
      localStorage.setItem("studentId", result.student.id.toString());
      localStorage.setItem("studentName", result.student.name);
      toast.success("¡Registro completado! Bienvenido/a a EuroconexiónPC");
      navigate("/alumno");
    } else {
      toast.error(result.message || "Error al registrar");
    }
  };

  const handleTeacherLogin = async () => {
    if (!teacherEmail.trim() || !teacherPassword.trim()) {
      toast.error("Por favor, introduce email y contraseña");
      return;
    }
    
    const result = await teacherLogin.mutateAsync({ 
      email: teacherEmail, 
      password: teacherPassword 
    });
    
    if (result.success && result.teacher) {
      localStorage.setItem("teacherId", result.teacher.id.toString());
      localStorage.setItem("teacherName", result.teacher.name);
      toast.success(`Bienvenido/a, ${result.teacher.name}`);
      navigate("/profesor");
    } else {
      toast.error("Email o contraseña incorrectos");
    }
  };

  const handleAdminLogin = async () => {
    if (!adminExists.data?.exists) {
      // First time setup
      if (!newAdminPassword.trim() || newAdminPassword !== confirmAdminPassword) {
        toast.error("Las contraseñas no coinciden o están vacías");
        return;
      }
      
      const result = await adminSetup.mutateAsync({ password: newAdminPassword });
      if (result.success) {
        localStorage.setItem("adminAuth", "true");
        toast.success("Contraseña de administrador configurada");
        navigate("/admin");
      } else {
        toast.error(result.message || "Error al configurar");
      }
    } else {
      // Normal login
      if (!adminPassword.trim()) {
        toast.error("Por favor, introduce la contraseña");
        return;
      }
      
      const result = await adminLogin.mutateAsync({ password: adminPassword });
      if (result.success) {
        localStorage.setItem("adminAuth", "true");
        toast.success("Acceso concedido");
        navigate("/admin");
      } else {
        toast.error("Contraseña incorrecta");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <EUFlag size={50} />
              <div>
                <h1 className="text-xl font-bold text-primary">EuroconexiónPC</h1>
                <p className="text-xs text-muted-foreground">Acciones Jean Monnet</p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground">
              <span>Cofinanciado por la</span>
              <span className="font-semibold text-primary">Unión Europea</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <BookOpen className="w-4 h-4" />
              IES Pérez Comendador - Plasencia
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Descubre la <span className="text-primary">Unión Europea</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Plataforma educativa interactiva sobre la historia de la Unión Europea 
              y los 40 años de España como Estado miembro. Aprende jugando con quizzes, 
              juegos de rol y escape rooms.
            </p>
            
            {/* Features */}
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto mb-12">
              <div className="flex flex-col items-center gap-2 p-4 rounded-lg bg-card border">
                <BookOpen className="w-6 h-6 text-primary" />
                <span className="text-xs font-medium">Contenidos</span>
              </div>
              <div className="flex flex-col items-center gap-2 p-4 rounded-lg bg-card border">
                <Gamepad2 className="w-6 h-6 text-accent" />
                <span className="text-xs font-medium">Gamificación</span>
              </div>
              <div className="flex flex-col items-center gap-2 p-4 rounded-lg bg-card border">
                <Trophy className="w-6 h-6 text-eu-gold" />
                <span className="text-xs font-medium">Rankings</span>
              </div>
            </div>
          </div>

          {/* Access Cards */}
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {/* Student Card */}
            <Card className="eu-card hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <GraduationCap className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-xl">Alumno</CardTitle>
                <CardDescription>
                  Accede a contenidos educativos y actividades interactivas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  className="w-full eu-btn-primary"
                  onClick={() => setShowStudentDialog(true)}
                >
                  Entrar como Alumno
                </Button>
              </CardContent>
            </Card>

            {/* Teacher Card */}
            <Card className="eu-card hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-accent/20 flex items-center justify-center">
                  <Users className="w-8 h-8 text-accent-foreground" />
                </div>
                <CardTitle className="text-xl">Profesor</CardTitle>
                <CardDescription>
                  Gestiona tus clases y consulta el progreso de tus alumnos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  className="w-full eu-btn-gold"
                  onClick={() => setShowTeacherDialog(true)}
                >
                  Entrar como Profesor
                </Button>
              </CardContent>
            </Card>

            {/* Admin Card */}
            <Card className="eu-card hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary flex items-center justify-center">
                  <Shield className="w-8 h-8 text-secondary-foreground" />
                </div>
                <CardTitle className="text-xl">Administrador</CardTitle>
                <CardDescription>
                  Administra profesores, alumnos y gestiona el sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="outline"
                  className="w-full border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                  onClick={() => {
                    setIsAdminSetup(!adminExists.data?.exists);
                    setShowAdminDialog(true);
                  }}
                >
                  Entrar como Admin
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-card/50 py-8 mt-auto">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <EUFlag size={40} />
              <div className="text-sm">
                <p className="font-semibold text-foreground"></p>
                <p className="text-muted-foreground">Cofinanciado por la Unión Europea</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 IES Pérez Comendador - Plasencia
            </p>
          </div>
        </div>
      </footer>

      {/* Student Dialog */}
      <Dialog open={showStudentDialog} onOpenChange={setShowStudentDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-primary" />
              Acceso de Alumno
            </DialogTitle>
            <DialogDescription>
              {showStudentRegister 
                ? "Completa tu registro para acceder a la plataforma"
                : "Introduce tu nombre y código de clase para acceder"
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="studentName">Nombre completo</Label>
              <Input
                id="studentName"
                placeholder="Tu nombre"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="classCode">Código de clase</Label>
              <Input
                id="classCode"
                placeholder="Ej: 1ESOA"
                value={classCode}
                onChange={(e) => setClassCode(e.target.value.toUpperCase())}
              />
            </div>
            
            {showStudentRegister ? (
              <Button 
                className="w-full eu-btn-primary" 
                onClick={handleStudentRegister}
                disabled={registerStudent.isPending}
              >
                {registerStudent.isPending ? "Registrando..." : "Completar Registro"}
              </Button>
            ) : (
              <Button 
                className="w-full eu-btn-primary" 
                onClick={handleStudentAccess}
                disabled={checkStudentExists.isFetching}
              >
                {checkStudentExists.isFetching ? "Verificando..." : "Acceder"}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Teacher Dialog */}
      <Dialog open={showTeacherDialog} onOpenChange={setShowTeacherDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-accent-foreground" />
              Acceso de Profesor
            </DialogTitle>
            <DialogDescription>
              Introduce tus credenciales para acceder al panel de profesor
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="teacherEmail">Email</Label>
              <Input
                id="teacherEmail"
                type="email"
                placeholder="tu@email.com"
                value={teacherEmail}
                onChange={(e) => setTeacherEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="teacherPassword">Contraseña</Label>
              <Input
                id="teacherPassword"
                type="password"
                placeholder="••••••••"
                value={teacherPassword}
                onChange={(e) => setTeacherPassword(e.target.value)}
              />
            </div>
            
            <Button 
              className="w-full eu-btn-gold" 
              onClick={handleTeacherLogin}
              disabled={teacherLogin.isPending}
            >
              {teacherLogin.isPending ? "Verificando..." : "Iniciar Sesión"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Admin Dialog */}
      <Dialog open={showAdminDialog} onOpenChange={setShowAdminDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              {isAdminSetup ? "Configurar Administrador" : "Acceso de Administrador"}
            </DialogTitle>
            <DialogDescription>
              {isAdminSetup 
                ? "Configura la contraseña de administrador por primera vez"
                : "Introduce la contraseña de administrador"
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {isAdminSetup ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="newAdminPassword">Nueva contraseña</Label>
                  <Input
                    id="newAdminPassword"
                    type="password"
                    placeholder="••••••••"
                    value={newAdminPassword}
                    onChange={(e) => setNewAdminPassword(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmAdminPassword">Confirmar contraseña</Label>
                  <Input
                    id="confirmAdminPassword"
                    type="password"
                    placeholder="••••••••"
                    value={confirmAdminPassword}
                    onChange={(e) => setConfirmAdminPassword(e.target.value)}
                  />
                </div>
              </>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="adminPassword">Contraseña</Label>
                <Input
                  id="adminPassword"
                  type="password"
                  placeholder="••••••••"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                />
              </div>
            )}
            
            <Button 
              className="w-full" 
              variant="default"
              onClick={handleAdminLogin}
              disabled={adminLogin.isPending || adminSetup.isPending}
            >
              {adminLogin.isPending || adminSetup.isPending 
                ? "Verificando..." 
                : isAdminSetup ? "Configurar" : "Acceder"
              }
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
