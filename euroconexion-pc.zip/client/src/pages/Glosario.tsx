import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EUFlag } from "@/components/EUStars";
import { glossaryTerms, getTermsByCategory } from "@/components/GlossaryTerm";
import { 
  ArrowLeft, Search, BookOpen, Building2, FileText, GraduationCap, 
  Euro, Flag, Users, Heart, MapPin, Sparkles
} from "lucide-react";

// Iconos por categoría
const categoryIcons: Record<string, React.ReactNode> = {
  "Instituciones": <Building2 className="w-5 h-5" />,
  "Tratados": <FileText className="w-5 h-5" />,
  "Programas": <GraduationCap className="w-5 h-5" />,
  "Políticas": <Sparkles className="w-5 h-5" />,
  "Economía": <Euro className="w-5 h-5" />,
  "Símbolos": <Flag className="w-5 h-5" />,
  "Personajes": <Users className="w-5 h-5" />,
  "Derechos": <Heart className="w-5 h-5" />,
  "España": <MapPin className="w-5 h-5" />,
};

// Colores por categoría
const categoryColors: Record<string, string> = {
  "Instituciones": "bg-blue-500",
  "Tratados": "bg-purple-500",
  "Programas": "bg-green-500",
  "Políticas": "bg-orange-500",
  "Economía": "bg-eu-gold",
  "Símbolos": "bg-primary",
  "Personajes": "bg-red-500",
  "Derechos": "bg-pink-500",
  "España": "bg-red-600",
};

export default function Glosario() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const termsByCategory = useMemo(() => getTermsByCategory(), []);
  const categories = Object.keys(termsByCategory);

  // Filtrar términos según búsqueda y categoría
  const filteredTerms = useMemo(() => {
    let terms = Object.entries(glossaryTerms);

    // Filtrar por categoría
    if (activeCategory !== "all") {
      terms = terms.filter(([, data]) => data.category === activeCategory);
    }

    // Filtrar por búsqueda
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      terms = terms.filter(([term, data]) =>
        term.toLowerCase().includes(query) ||
        data.definition.toLowerCase().includes(query)
      );
    }

    // Ordenar alfabéticamente
    return terms.sort((a, b) => a[0].localeCompare(b[0], 'es'));
  }, [searchQuery, activeCategory]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate("/alumno")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">Glosario Europeo</h1>
                <p className="text-xs text-muted-foreground">Términos clave de la Unión Europea</p>
              </div>
            </div>
            <Badge variant="outline" className="hidden md:flex">
              <BookOpen className="w-3 h-3 mr-1" />
              {Object.keys(glossaryTerms).length} términos
            </Badge>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary/10 via-eu-gold/10 to-primary/10 py-10">
        <div className="container text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/20 rounded-full mb-4">
            <BookOpen className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-3xl font-bold mb-3">Glosario de la Unión Europea</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
            Descubre el significado de los términos más importantes sobre la Unión Europea. 
            Busca por palabra clave o explora por categorías.
          </p>
          
          {/* Buscador */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Buscar término..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-lg"
            />
          </div>
        </div>
      </section>

      {/* Estadísticas rápidas */}
      <section className="container py-6">
        <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2">
          {categories.map((category) => (
            <Card 
              key={category}
              className={`cursor-pointer transition-all hover:shadow-md ${
                activeCategory === category ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => setActiveCategory(activeCategory === category ? "all" : category)}
            >
              <CardContent className="p-3 text-center">
                <div className={`w-8 h-8 ${categoryColors[category]} rounded-full flex items-center justify-center mx-auto mb-1 text-white`}>
                  {categoryIcons[category]}
                </div>
                <p className="text-xs font-medium truncate">{category}</p>
                <p className="text-lg font-bold text-primary">{termsByCategory[category]?.length || 0}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        {activeCategory !== "all" && (
          <div className="text-center mt-4">
            <Button variant="ghost" size="sm" onClick={() => setActiveCategory("all")}>
              Ver todos los términos
            </Button>
          </div>
        )}
      </section>

      {/* Lista de términos */}
      <main className="container py-8">
        {searchQuery && (
          <p className="text-muted-foreground mb-4">
            {filteredTerms.length} resultado{filteredTerms.length !== 1 ? 's' : ''} para "{searchQuery}"
          </p>
        )}

        {filteredTerms.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No se encontraron términos</h3>
              <p className="text-muted-foreground">
                Intenta con otra palabra clave o explora las categorías.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTerms.map(([term, data]) => (
              <TermCard 
                key={term} 
                term={term} 
                definition={data.definition} 
                category={data.category} 
              />
            ))}
          </div>
        )}
      </main>

      {/* Sección de ayuda */}
      <section className="container pb-12">
        <Card className="bg-gradient-to-r from-primary/5 to-eu-gold/5 border-primary/20">
          <CardContent className="py-6">
            <div className="flex items-start gap-4">
              <div className="bg-primary/20 p-3 rounded-full shrink-0">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">💡 ¿Sabías que...?</h3>
                <p className="text-muted-foreground">
                  En las secciones de <strong>Historia de la UE</strong> y <strong>40 años de España en la UE</strong>, 
                  los términos del glosario aparecen <span className="border-b border-dashed border-primary text-primary">subrayados</span>. 
                  Pasa el cursor por encima para ver su definición sin salir de la página.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Back Button */}
      <div className="container pb-12 text-center">
        <Button 
          size="lg" 
          className="eu-btn-primary"
          onClick={() => navigate("/alumno")}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver al perfil
        </Button>
      </div>

      {/* Footer */}
      <footer className="border-t bg-card/50 py-6">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <EUFlag size={32} />
              <div className="text-sm">
                <p className="text-muted-foreground">Cofinanciado por la Unión Europea</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              IES Pérez Comendador - Plasencia | EuroconexiónPC
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Componente de tarjeta de término
function TermCard({ term, definition, category }: { term: string; definition: string; category: string }) {
  return (
    <Card className="hover:shadow-lg transition-all group">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-lg group-hover:text-primary transition-colors">
            {term}
          </CardTitle>
          <Badge 
            variant="outline" 
            className="shrink-0 text-xs"
            style={{ 
              borderColor: `var(--${category.toLowerCase()}-color, hsl(var(--primary)))`,
            }}
          >
            {category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {definition}
        </p>
      </CardContent>
    </Card>
  );
}
