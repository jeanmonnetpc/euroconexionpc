import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { EUFlag } from "@/components/EUStars";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { 
  ArrowLeft, Users, Vote, ThumbsUp, ThumbsDown, 
  Scale, Trophy, Building2, FileText, ArrowRight
} from "lucide-react";

// Scenarios for the roleplay
const scenarios = [
  {
    id: 1,
    title: "Ley de Inteligencia Artificial",
    description: "El Parlamento Europeo debate una nueva ley para regular el uso de la inteligencia artificial en la UE.",
    context: "La propuesta establece normas para garantizar que la IA sea segura, transparente y respetuosa con los derechos fundamentales. Incluye prohibiciones de ciertos usos de alto riesgo y requisitos de transparencia.",
    arguments: {
      favor: [
        "Protege los derechos fundamentales de los ciudadanos",
        "Establece un marco legal claro para las empresas",
        "Posiciona a la UE como líder mundial en regulación ética de IA",
      ],
      contra: [
        "Podría frenar la innovación tecnológica europea",
        "Las empresas podrían trasladarse a países con menos regulación",
        "Los requisitos podrían ser demasiado costosos para las pymes",
      ],
    },
    correctVote: "favor",
    explanation: "El Parlamento Europeo aprobó la Ley de IA en 2024, convirtiéndose en la primera regulación integral de IA del mundo. La UE considera que la protección de los derechos fundamentales debe primar sobre los intereses comerciales.",
  },
  {
    id: 2,
    title: "Pacto Verde Europeo",
    description: "Se vota una propuesta para alcanzar la neutralidad climática en 2050.",
    context: "El Pacto Verde Europeo es un conjunto de iniciativas políticas para que la UE sea climáticamente neutra en 2050. Incluye inversiones en energías renovables, eficiencia energética y economía circular.",
    arguments: {
      favor: [
        "Combate el cambio climático de forma decidida",
        "Crea nuevos empleos verdes y oportunidades económicas",
        "Reduce la dependencia energética de terceros países",
      ],
      contra: [
        "Los costes de transición son muy elevados",
        "Podría afectar a sectores industriales tradicionales",
        "Otros grandes emisores no asumen compromisos similares",
      ],
    },
    correctVote: "favor",
    explanation: "El Pacto Verde Europeo fue aprobado y es una prioridad de la UE. La transición ecológica se considera esencial para el futuro de Europa y una oportunidad de liderazgo global.",
  },
  {
    id: 3,
    title: "Reglamento de Servicios Digitales",
    description: "Nueva normativa para regular las grandes plataformas digitales y proteger a los usuarios.",
    context: "El Reglamento de Servicios Digitales (DSA) establece nuevas obligaciones para las plataformas online, incluyendo la moderación de contenidos ilegales, transparencia algorítmica y protección de menores.",
    arguments: {
      favor: [
        "Protege a los usuarios de contenidos dañinos e ilegales",
        "Aumenta la transparencia de los algoritmos",
        "Crea un entorno digital más seguro para los menores",
      ],
      contra: [
        "Podría limitar la libertad de expresión online",
        "Las plataformas pequeñas tendrán dificultades para cumplir",
        "La moderación de contenidos es compleja y subjetiva",
      ],
    },
    correctVote: "favor",
    explanation: "El DSA fue aprobado en 2022 y entró en vigor en 2024. La UE considera prioritario que las grandes plataformas asuman responsabilidad por los contenidos que difunden.",
  },
  {
    id: 4,
    title: "Directiva de Salarios Mínimos",
    description: "Propuesta para establecer criterios comunes sobre salarios mínimos en la UE.",
    context: "La directiva no fija un salario mínimo único europeo, sino que establece criterios para que los Estados miembros garanticen salarios mínimos adecuados, ya sea por ley o mediante negociación colectiva.",
    arguments: {
      favor: [
        "Mejora las condiciones de vida de los trabajadores",
        "Reduce la pobreza laboral en la UE",
        "Promueve la convergencia social entre Estados miembros",
      ],
      contra: [
        "Interfiere en las competencias nacionales",
        "Podría aumentar el desempleo en algunos sectores",
        "Los países nórdicos prefieren la negociación colectiva",
      ],
    },
    correctVote: "favor",
    explanation: "La Directiva fue aprobada en 2022. Respeta los diferentes modelos nacionales pero establece un marco para garantizar salarios dignos en toda la UE.",
  },
  {
    id: 5,
    title: "Fondo de Recuperación NextGenerationEU",
    description: "Aprobación del mayor paquete de estímulo económico de la historia de la UE.",
    context: "NextGenerationEU es un instrumento de recuperación temporal de 750.000 millones de euros para reparar los daños económicos y sociales de la pandemia de COVID-19 y preparar a Europa para el futuro.",
    arguments: {
      favor: [
        "Impulsa la recuperación económica post-pandemia",
        "Financia la transición verde y digital",
        "Demuestra solidaridad europea en tiempos de crisis",
      ],
      contra: [
        "Supone un endeudamiento común sin precedentes",
        "Los países frugales asumen riesgos de otros Estados",
        "Podría crear dependencia de los fondos europeos",
      ],
    },
    correctVote: "favor",
    explanation: "NextGenerationEU fue aprobado en 2020 como respuesta histórica a la pandemia. España es uno de los principales beneficiarios con más de 140.000 millones de euros.",
  },
];

export default function Roleplay() {
  const [, navigate] = useLocation();
  const [studentId, setStudentId] = useState<number | null>(null);
  const [currentScenario, setCurrentScenario] = useState(0);
  const [votes, setVotes] = useState<("favor" | "contra" | null)[]>(new Array(scenarios.length).fill(null));
  const [showResult, setShowResult] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameFinished, setGameFinished] = useState(false);

  const saveScore = trpc.student.saveScore.useMutation();

  // Check auth
  useEffect(() => {
    const id = localStorage.getItem("studentId");
    if (!id) {
      navigate("/");
    } else {
      setStudentId(parseInt(id));
    }
  }, [navigate]);

  const handleVote = (vote: "favor" | "contra") => {
    const newVotes = [...votes];
    newVotes[currentScenario] = vote;
    setVotes(newVotes);
    setShowResult(true);
  };

  const handleNext = () => {
    if (currentScenario < scenarios.length - 1) {
      setCurrentScenario(currentScenario + 1);
      setShowResult(false);
    } else {
      setGameFinished(true);
      calculateAndSaveScore();
    }
  };

  const calculateAndSaveScore = async () => {
    if (!studentId) return;

    const correctVotes = votes.filter((vote, index) => vote === scenarios[index].correctVote).length;
    const score = Math.round((correctVotes / scenarios.length) * 300);

    await saveScore.mutateAsync({
      studentId,
      activityType: "roleplay",
      score,
      maxScore: 300,
    });

    toast.success(`¡Juego completado! Has obtenido ${score} puntos`);
  };

  const correctVotes = votes.filter((vote, index) => vote === scenarios[index].correctVote).length;
  const score = Math.round((correctVotes / scenarios.length) * 300);

  const scenario = scenarios[currentScenario];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate("/alumno")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">Eurodiputado por un día</h1>
                <Badge variant="secondary">Juego de Rol</Badge>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8 max-w-4xl">
        {!gameStarted ? (
          // Start Screen
          <Card className="eu-card">
            <CardHeader className="text-center">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Building2 className="w-10 h-10 text-primary" />
              </div>
              <CardTitle className="text-2xl">Eurodiputado por un día</CardTitle>
              <CardDescription className="text-base mt-2">
                Ponte en la piel de un eurodiputado y vota sobre leyes y reglamentos reales de la UE
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="p-6 rounded-xl bg-primary/5 border border-primary/20">
                <h3 className="font-semibold mb-3">¿Cómo funciona?</h3>
                <ul className="text-left space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <FileText className="w-5 h-5 mt-0.5 text-primary" />
                    <span>Se te presentarán 5 propuestas legislativas reales de la UE</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Scale className="w-5 h-5 mt-0.5 text-primary" />
                    <span>Analiza los argumentos a favor y en contra</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Vote className="w-5 h-5 mt-0.5 text-primary" />
                    <span>Vota como lo haría un eurodiputado responsable</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Trophy className="w-5 h-5 mt-0.5 text-eu-gold" />
                    <span>Gana hasta 300 puntos según tus decisiones</span>
                  </li>
                </ul>
              </div>
              
              <Button size="lg" className="eu-btn-primary" onClick={() => setGameStarted(true)}>
                <Users className="w-5 h-5 mr-2" />
                Comenzar sesión parlamentaria
              </Button>
            </CardContent>
          </Card>
        ) : gameFinished ? (
          // Results Screen
          <Card className="eu-card">
            <CardHeader className="text-center">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-eu-gold/20 flex items-center justify-center">
                <Trophy className="w-10 h-10 text-eu-gold" />
              </div>
              <CardTitle className="text-2xl">¡Sesión Parlamentaria Finalizada!</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="p-6 rounded-xl bg-gradient-to-br from-primary/10 to-eu-gold/10">
                <p className="text-5xl font-bold text-primary mb-2">{score}</p>
                <p className="text-muted-foreground">de 300 puntos</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-green-500/10">
                  <p className="text-2xl font-bold text-green-500">{correctVotes}</p>
                  <p className="text-sm text-muted-foreground">Votos acertados</p>
                </div>
                <div className="p-4 rounded-lg bg-red-500/10">
                  <p className="text-2xl font-bold text-red-500">{scenarios.length - correctVotes}</p>
                  <p className="text-sm text-muted-foreground">Votos diferentes</p>
                </div>
              </div>

              <p className="text-muted-foreground">
                {correctVotes >= 4 
                  ? "¡Excelente! Tienes madera de eurodiputado."
                  : correctVotes >= 3
                  ? "¡Bien hecho! Entiendes el funcionamiento de la UE."
                  : "Sigue aprendiendo sobre las políticas europeas."}
              </p>

              <Button 
                size="lg" 
                className="eu-btn-primary"
                onClick={() => navigate("/alumno")}
              >
                Volver al perfil
              </Button>
            </CardContent>
          </Card>
        ) : (
          // Game Screen
          <div className="space-y-6">
            {/* Progress */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  Propuesta {currentScenario + 1} de {scenarios.length}
                </span>
                <span className="font-medium">{Math.round(((currentScenario + 1) / scenarios.length) * 100)}%</span>
              </div>
              <Progress value={((currentScenario + 1) / scenarios.length) * 100} className="h-2" />
            </div>

            {/* Scenario Card */}
            <Card className="eu-card">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline">Propuesta Legislativa</Badge>
                </div>
                <CardTitle className="text-xl">{scenario.title}</CardTitle>
                <CardDescription className="text-base">
                  {scenario.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Context */}
                <div className="p-4 rounded-lg bg-secondary/50">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Contexto
                  </h4>
                  <p className="text-sm text-muted-foreground">{scenario.context}</p>
                </div>

                {/* Arguments */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                    <h4 className="font-semibold mb-3 flex items-center gap-2 text-green-700">
                      <ThumbsUp className="w-4 h-4" />
                      Argumentos a favor
                    </h4>
                    <ul className="space-y-2">
                      {scenario.arguments.favor.map((arg, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                          <span className="text-green-500">•</span>
                          {arg}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                    <h4 className="font-semibold mb-3 flex items-center gap-2 text-red-700">
                      <ThumbsDown className="w-4 h-4" />
                      Argumentos en contra
                    </h4>
                    <ul className="space-y-2">
                      {scenario.arguments.contra.map((arg, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                          <span className="text-red-500">•</span>
                          {arg}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Voting or Result */}
                {!showResult ? (
                  <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                    <Button 
                      size="lg" 
                      className="bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => handleVote("favor")}
                    >
                      <ThumbsUp className="w-5 h-5 mr-2" />
                      Votar A FAVOR
                    </Button>
                    <Button 
                      size="lg" 
                      className="bg-red-600 hover:bg-red-700 text-white"
                      onClick={() => handleVote("contra")}
                    >
                      <ThumbsDown className="w-5 h-5 mr-2" />
                      Votar EN CONTRA
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className={`p-4 rounded-lg ${
                      votes[currentScenario] === scenario.correctVote 
                        ? "bg-green-500/10 border border-green-500" 
                        : "bg-red-500/10 border border-red-500"
                    }`}>
                      <h4 className="font-semibold mb-2">
                        {votes[currentScenario] === scenario.correctVote 
                          ? "✓ ¡Votaste igual que el Parlamento Europeo!" 
                          : "✗ El Parlamento Europeo votó diferente"}
                      </h4>
                      <p className="text-sm text-muted-foreground">{scenario.explanation}</p>
                    </div>
                    <div className="flex justify-center">
                      <Button className="eu-btn-primary" onClick={handleNext}>
                        {currentScenario < scenarios.length - 1 ? (
                          <>
                            Siguiente propuesta
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </>
                        ) : (
                          "Ver resultados"
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
