import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { EUFlag } from "@/components/EUStars";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { 
  Users, GraduationCap, Trophy, Trash2, 
  LogOut, Key, School, Medal
} from "lucide-react";

export default function Teacher() {
  const [, navigate] = useLocation();
  const [teacherId, setTeacherId] = useState<number | null>(null);
  const [teacherName, setTeacherName] = useState("");
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [passwordForm, setPasswordForm] = useState({ current: "", new: "", confirm: "" });
  
  // Check auth
  useEffect(() => {
    const id = localStorage.getItem("teacherId");
    const name = localStorage.getItem("teacherName");
    if (!id) {
      navigate("/");
    } else {
      setTeacherId(parseInt(id));
      setTeacherName(name || "");
    }
  }, [navigate]);

  // tRPC queries
  const teacherClasses = trpc.teacher.getClasses.useQuery(
    { teacherId: teacherId! },
    { enabled: !!teacherId }
  );
  
  // tRPC mutations
  const deleteStudent = trpc.student.delete.useMutation();
  const changePassword = trpc.teacher.changePassword.useMutation();

  const handleLogout = () => {
    localStorage.removeItem("teacherId");
    localStorage.removeItem("teacherName");
    navigate("/");
  };

  const handleChangePassword = async () => {
    if (!teacherId) return;
    
    if (passwordForm.new !== passwordForm.confirm) {
      toast.error("Las contraseñas no coinciden");
      return;
    }
    
    const result = await changePassword.mutateAsync({
      id: teacherId,
      currentPassword: passwordForm.current,
      newPassword: passwordForm.new,
    });
    
    if (result.success) {
      toast.success("Contraseña actualizada");
      setShowChangePassword(false);
      setPasswordForm({ current: "", new: "", confirm: "" });
    } else {
      toast.error(result.message || "Error al cambiar contraseña");
    }
  };

  if (!teacherId) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">EuroconexiónPC</h1>
                <p className="text-xs text-muted-foreground">Panel de Profesor</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground hidden sm:inline">
                Hola, <span className="font-medium text-foreground">{teacherName}</span>
              </span>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowChangePassword(true)}
              >
                <Key className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Contraseña</span>
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
            <Users className="w-6 h-6 text-accent-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Mis Clases</h2>
            <p className="text-muted-foreground">Consulta el progreso y ranking de tus alumnos</p>
          </div>
        </div>

        {teacherClasses.data?.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <School className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Sin clases asignadas</h3>
              <p className="text-muted-foreground">
                El administrador aún no te ha asignado ninguna clase.
              </p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue={teacherClasses.data?.[0]?.classId.toString()} className="space-y-6">
            <TabsList className="flex-wrap h-auto gap-2">
              {teacherClasses.data?.map((tc) => (
                <TabsTrigger key={tc.classId} value={tc.classId.toString()} className="gap-2">
                  <School className="w-4 h-4" />
                  {tc.className}
                </TabsTrigger>
              ))}
            </TabsList>

            {teacherClasses.data?.map((tc) => (
              <TabsContent key={tc.classId} value={tc.classId.toString()}>
                <ClassRanking 
                  classId={tc.classId} 
                  className={tc.className}
                  classCode={tc.classCode}
                  onDeleteStudent={(id) => {
                    deleteStudent.mutateAsync({ id }).then(() => {
                      toast.success("Alumno eliminado");
                    });
                  }}
                />
              </TabsContent>
            ))}
          </Tabs>
        )}
      </main>

      {/* Change Password Dialog */}
      <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cambiar Contraseña</DialogTitle>
            <DialogDescription>Introduce tu contraseña actual y la nueva</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Contraseña actual</Label>
              <Input
                type="password"
                value={passwordForm.current}
                onChange={(e) => setPasswordForm({ ...passwordForm, current: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Nueva contraseña</Label>
              <Input
                type="password"
                value={passwordForm.new}
                onChange={(e) => setPasswordForm({ ...passwordForm, new: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Confirmar nueva contraseña</Label>
              <Input
                type="password"
                value={passwordForm.confirm}
                onChange={(e) => setPasswordForm({ ...passwordForm, confirm: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowChangePassword(false)}>Cancelar</Button>
            <Button onClick={handleChangePassword} disabled={changePassword.isPending}>
              {changePassword.isPending ? "Cambiando..." : "Cambiar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Component to show class ranking
function ClassRanking({ 
  classId, 
  className, 
  classCode,
  onDeleteStudent 
}: { 
  classId: number; 
  className: string;
  classCode: string;
  onDeleteStudent: (id: number) => void;
}) {
  const ranking = trpc.teacher.getClassRanking.useQuery({ classId });
  const utils = trpc.useUtils();

  const handleDelete = async (studentId: number) => {
    if (!confirm("¿Estás seguro de eliminar este alumno?")) return;
    onDeleteStudent(studentId);
    utils.teacher.getClassRanking.invalidate({ classId });
  };

  const getMedalColor = (position: number) => {
    switch (position) {
      case 0: return "text-yellow-500";
      case 1: return "text-gray-400";
      case 2: return "text-amber-600";
      default: return "text-muted-foreground";
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-eu-gold" />
              Ranking de {className}
            </CardTitle>
            <CardDescription>
              Código de clase: <Badge variant="outline">{classCode}</Badge>
            </CardDescription>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-primary">{ranking.data?.length || 0}</p>
            <p className="text-xs text-muted-foreground">alumnos</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Pos.</TableHead>
              <TableHead>Alumno</TableHead>
              <TableHead>Puntos</TableHead>
              <TableHead>Actividades completadas</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {ranking.data?.map((entry, index) => (
              <TableRow key={entry.studentId}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {index < 3 ? (
                      <Medal className={`w-5 h-5 ${getMedalColor(index)}`} />
                    ) : (
                      <span className="w-5 text-center text-muted-foreground">{index + 1}</span>
                    )}
                  </div>
                </TableCell>
                <TableCell className="font-medium">{entry.studentName}</TableCell>
                <TableCell>
                  <span className="font-bold text-primary text-lg">{entry.totalPoints}</span>
                  <span className="text-muted-foreground text-sm"> pts</span>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    <Badge 
                      variant={entry.quiz1Completed ? "default" : "outline"} 
                      className="text-xs"
                    >
                      Quiz 1
                    </Badge>
                    <Badge 
                      variant={entry.quiz2Completed ? "default" : "outline"} 
                      className="text-xs"
                    >
                      Quiz 2
                    </Badge>
                    <Badge 
                      variant={entry.quiz3Completed ? "default" : "outline"} 
                      className="text-xs"
                    >
                      Quiz 3
                    </Badge>
                    <Badge 
                      variant={entry.roleplayCompleted ? "default" : "outline"} 
                      className="text-xs"
                    >
                      Rol
                    </Badge>
                    <Badge 
                      variant={entry.escaperoomCompleted ? "default" : "outline"} 
                      className="text-xs"
                    >
                      Escape
                    </Badge>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="destructive" 
                    size="sm"
                    onClick={() => handleDelete(entry.studentId)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {ranking.data?.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                  <GraduationCap className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  No hay alumnos en esta clase
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
