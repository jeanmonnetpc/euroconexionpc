import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { EUFlag } from "@/components/EUStars";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { 
  Shield, Users, GraduationCap, Trophy, Plus, Trash2, 
  LogOut, Key, UserPlus, School, RefreshCw, Settings
} from "lucide-react";

export default function Admin() {
  const [, navigate] = useLocation();
  const [showAddTeacher, setShowAddTeacher] = useState(false);
  const [showAddClass, setShowAddClass] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showAssignClass, setShowAssignClass] = useState(false);
  const [selectedTeacherId, setSelectedTeacherId] = useState<number | null>(null);
  
  // Form states
  const [newTeacher, setNewTeacher] = useState({ name: "", email: "", password: "" });
  const [newClass, setNewClass] = useState({ name: "", code: "" });
  const [passwordForm, setPasswordForm] = useState({ current: "", new: "", confirm: "" });
  const [selectedClassId, setSelectedClassId] = useState<string>("");
  
  // tRPC queries
  const teachers = trpc.teacher.list.useQuery();
  const classes = trpc.class.list.useQuery();
  const students = trpc.student.list.useQuery();
  const globalRanking = trpc.ranking.global.useQuery();
  
  // tRPC mutations
  const createTeacher = trpc.teacher.create.useMutation();
  const deleteTeacher = trpc.teacher.delete.useMutation();
  const createClass = trpc.class.create.useMutation();
  const deleteClass = trpc.class.delete.useMutation();
  const deleteStudent = trpc.student.delete.useMutation();
  const assignClass = trpc.teacher.assignClass.useMutation();
  const removeClass = trpc.teacher.removeClass.useMutation();
  const resetAllRankings = trpc.ranking.resetAll.useMutation();
  const resetStudentRanking = trpc.ranking.resetStudent.useMutation();
  const changePassword = trpc.admin.changePassword.useMutation();

  // Check auth
  useEffect(() => {
    const isAuth = localStorage.getItem("adminAuth");
    if (!isAuth) {
      navigate("/");
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("adminAuth");
    navigate("/");
  };

  const handleAddTeacher = async () => {
    if (!newTeacher.name || !newTeacher.email || !newTeacher.password) {
      toast.error("Completa todos los campos");
      return;
    }
    
    const result = await createTeacher.mutateAsync(newTeacher);
    if (result.success) {
      toast.success("Profesor añadido correctamente");
      setShowAddTeacher(false);
      setNewTeacher({ name: "", email: "", password: "" });
      teachers.refetch();
    } else {
      toast.error(result.message || "Error al añadir profesor");
    }
  };

  const handleDeleteTeacher = async (id: number) => {
    if (!confirm("¿Estás seguro de eliminar este profesor?")) return;
    
    await deleteTeacher.mutateAsync({ id });
    toast.success("Profesor eliminado");
    teachers.refetch();
  };

  const handleAddClass = async () => {
    if (!newClass.name || !newClass.code) {
      toast.error("Completa todos los campos");
      return;
    }
    
    const result = await createClass.mutateAsync(newClass);
    if (result.success) {
      toast.success("Clase creada correctamente");
      setShowAddClass(false);
      setNewClass({ name: "", code: "" });
      classes.refetch();
    } else {
      toast.error(result.message || "Error al crear clase");
    }
  };

  const handleDeleteClass = async (id: number) => {
    if (!confirm("¿Estás seguro de eliminar esta clase? Se eliminarán también los alumnos asociados.")) return;
    
    await deleteClass.mutateAsync({ id });
    toast.success("Clase eliminada");
    classes.refetch();
    students.refetch();
  };

  const handleDeleteStudent = async (id: number) => {
    if (!confirm("¿Estás seguro de eliminar este alumno?")) return;
    
    await deleteStudent.mutateAsync({ id });
    toast.success("Alumno eliminado");
    students.refetch();
    globalRanking.refetch();
  };

  const handleAssignClass = async () => {
    if (!selectedTeacherId || !selectedClassId) {
      toast.error("Selecciona una clase");
      return;
    }
    
    await assignClass.mutateAsync({ 
      teacherId: selectedTeacherId, 
      classId: parseInt(selectedClassId) 
    });
    toast.success("Clase asignada correctamente");
    setShowAssignClass(false);
    setSelectedClassId("");
    teachers.refetch();
  };

  const handleResetAllRankings = async () => {
    if (!confirm("¿Estás seguro de resetear TODOS los rankings? Esta acción no se puede deshacer.")) return;
    
    await resetAllRankings.mutateAsync();
    toast.success("Rankings reseteados");
    globalRanking.refetch();
  };

  const handleResetStudentRanking = async (studentId: number) => {
    if (!confirm("¿Resetear el ranking de este alumno?")) return;
    
    await resetStudentRanking.mutateAsync({ studentId });
    toast.success("Ranking del alumno reseteado");
    globalRanking.refetch();
  };

  const handleChangePassword = async () => {
    if (passwordForm.new !== passwordForm.confirm) {
      toast.error("Las contraseñas no coinciden");
      return;
    }
    
    const result = await changePassword.mutateAsync({
      currentPassword: passwordForm.current,
      newPassword: passwordForm.new,
    });
    
    if (result.success) {
      toast.success("Contraseña actualizada");
      setShowChangePassword(false);
      setPasswordForm({ current: "", new: "", confirm: "" });
    } else {
      toast.error(result.message || "Error al cambiar contraseña");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <EUFlag size={40} />
              <div>
                <h1 className="text-lg font-bold text-primary">EuroconexiónPC</h1>
                <p className="text-xs text-muted-foreground">Panel de Administrador</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowChangePassword(true)}
              >
                <Key className="w-4 h-4 mr-2" />
                Cambiar Contraseña
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Panel de Administración</h2>
            <p className="text-muted-foreground">Gestiona profesores, alumnos y rankings</p>
          </div>
        </div>

        <Tabs defaultValue="teachers" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="teachers" className="gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Profesores</span>
            </TabsTrigger>
            <TabsTrigger value="classes" className="gap-2">
              <School className="w-4 h-4" />
              <span className="hidden sm:inline">Clases</span>
            </TabsTrigger>
            <TabsTrigger value="students" className="gap-2">
              <GraduationCap className="w-4 h-4" />
              <span className="hidden sm:inline">Alumnos</span>
            </TabsTrigger>
            <TabsTrigger value="ranking" className="gap-2">
              <Trophy className="w-4 h-4" />
              <span className="hidden sm:inline">Ranking</span>
            </TabsTrigger>
          </TabsList>

          {/* Teachers Tab */}
          <TabsContent value="teachers">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Gestión de Profesores</CardTitle>
                    <CardDescription>Añade, elimina y asigna clases a los profesores</CardDescription>
                  </div>
                  <Button onClick={() => setShowAddTeacher(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Añadir Profesor
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Clases</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teachers.data?.map((teacher) => (
                      <TableRow key={teacher.id}>
                        <TableCell className="font-medium">{teacher.name}</TableCell>
                        <TableCell>{teacher.email}</TableCell>
                        <TableCell>
                          <TeacherClasses teacherId={teacher.id} />
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedTeacherId(teacher.id);
                                setShowAssignClass(true);
                              }}
                            >
                              <School className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => handleDeleteTeacher(teacher.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {teachers.data?.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          No hay profesores registrados
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Classes Tab */}
          <TabsContent value="classes">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Gestión de Clases</CardTitle>
                    <CardDescription>Crea y elimina clases del sistema</CardDescription>
                  </div>
                  <Button onClick={() => setShowAddClass(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Nueva Clase
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Código</TableHead>
                      <TableHead>Alumnos</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {classes.data?.map((cls) => (
                      <TableRow key={cls.id}>
                        <TableCell className="font-medium">{cls.name}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{cls.code}</Badge>
                        </TableCell>
                        <TableCell>
                          {students.data?.filter(s => s.classId === cls.id).length || 0}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="destructive" 
                            size="sm"
                            onClick={() => handleDeleteClass(cls.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {classes.data?.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          No hay clases creadas
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Students Tab */}
          <TabsContent value="students">
            <Card>
              <CardHeader>
                <CardTitle>Gestión de Alumnos</CardTitle>
                <CardDescription>Visualiza y elimina alumnos registrados</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Clase</TableHead>
                      <TableHead>Registro</TableHead>
                      <TableHead>Último acceso</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {students.data?.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{student.classCode}</Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {new Date(student.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {new Date(student.lastAccess).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="destructive" 
                            size="sm"
                            onClick={() => handleDeleteStudent(student.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {students.data?.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                          No hay alumnos registrados
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Ranking Tab */}
          <TabsContent value="ranking">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Ranking Global</CardTitle>
                    <CardDescription>Puntuaciones de todos los alumnos</CardDescription>
                  </div>
                  <Button variant="destructive" onClick={handleResetAllRankings}>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Resetear Todo
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-16">#</TableHead>
                      <TableHead>Alumno</TableHead>
                      <TableHead>Clase</TableHead>
                      <TableHead>Puntos</TableHead>
                      <TableHead>Actividades</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {globalRanking.data?.map((entry, index) => (
                      <TableRow key={entry.studentId}>
                        <TableCell>
                          <Badge variant={index < 3 ? "default" : "secondary"}>
                            {index + 1}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">{entry.studentName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{entry.className}</Badge>
                        </TableCell>
                        <TableCell>
                          <span className="font-bold text-primary">{entry.totalPoints}</span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {entry.quiz1Completed && <Badge variant="secondary" className="text-xs">Q1</Badge>}
                            {entry.quiz2Completed && <Badge variant="secondary" className="text-xs">Q2</Badge>}
                            {entry.quiz3Completed && <Badge variant="secondary" className="text-xs">Q3</Badge>}
                            {entry.roleplayCompleted && <Badge variant="secondary" className="text-xs">RP</Badge>}
                            {entry.escaperoomCompleted && <Badge variant="secondary" className="text-xs">ER</Badge>}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleResetStudentRanking(entry.studentId)}
                            >
                              <RefreshCw className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => handleDeleteStudent(entry.studentId)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {globalRanking.data?.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No hay datos de ranking
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Add Teacher Dialog */}
      <Dialog open={showAddTeacher} onOpenChange={setShowAddTeacher}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Añadir Profesor</DialogTitle>
            <DialogDescription>Introduce los datos del nuevo profesor</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Nombre</Label>
              <Input
                value={newTeacher.name}
                onChange={(e) => setNewTeacher({ ...newTeacher, name: e.target.value })}
                placeholder="Nombre completo"
              />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input
                type="email"
                value={newTeacher.email}
                onChange={(e) => setNewTeacher({ ...newTeacher, email: e.target.value })}
                placeholder="email@ejemplo.com"
              />
            </div>
            <div className="space-y-2">
              <Label>Contraseña inicial</Label>
              <Input
                type="password"
                value={newTeacher.password}
                onChange={(e) => setNewTeacher({ ...newTeacher, password: e.target.value })}
                placeholder="••••••••"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddTeacher(false)}>Cancelar</Button>
            <Button onClick={handleAddTeacher} disabled={createTeacher.isPending}>
              {createTeacher.isPending ? "Añadiendo..." : "Añadir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Class Dialog */}
      <Dialog open={showAddClass} onOpenChange={setShowAddClass}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nueva Clase</DialogTitle>
            <DialogDescription>Crea una nueva clase en el sistema</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Nombre de la clase</Label>
              <Input
                value={newClass.name}
                onChange={(e) => setNewClass({ ...newClass, name: e.target.value })}
                placeholder="Ej: 1º ESO A"
              />
            </div>
            <div className="space-y-2">
              <Label>Código (único)</Label>
              <Input
                value={newClass.code}
                onChange={(e) => setNewClass({ ...newClass, code: e.target.value.toUpperCase() })}
                placeholder="Ej: 1ESOA"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddClass(false)}>Cancelar</Button>
            <Button onClick={handleAddClass} disabled={createClass.isPending}>
              {createClass.isPending ? "Creando..." : "Crear"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Class Dialog */}
      <Dialog open={showAssignClass} onOpenChange={setShowAssignClass}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Asignar Clase</DialogTitle>
            <DialogDescription>Selecciona una clase para asignar al profesor</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Select value={selectedClassId} onValueChange={setSelectedClassId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una clase" />
              </SelectTrigger>
              <SelectContent>
                {classes.data?.map((cls) => (
                  <SelectItem key={cls.id} value={cls.id.toString()}>
                    {cls.name} ({cls.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAssignClass(false)}>Cancelar</Button>
            <Button onClick={handleAssignClass} disabled={assignClass.isPending}>
              {assignClass.isPending ? "Asignando..." : "Asignar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change Password Dialog */}
      <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cambiar Contraseña</DialogTitle>
            <DialogDescription>Introduce tu contraseña actual y la nueva</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Contraseña actual</Label>
              <Input
                type="password"
                value={passwordForm.current}
                onChange={(e) => setPasswordForm({ ...passwordForm, current: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Nueva contraseña</Label>
              <Input
                type="password"
                value={passwordForm.new}
                onChange={(e) => setPasswordForm({ ...passwordForm, new: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Confirmar nueva contraseña</Label>
              <Input
                type="password"
                value={passwordForm.confirm}
                onChange={(e) => setPasswordForm({ ...passwordForm, confirm: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowChangePassword(false)}>Cancelar</Button>
            <Button onClick={handleChangePassword} disabled={changePassword.isPending}>
              {changePassword.isPending ? "Cambiando..." : "Cambiar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Component to show teacher's assigned classes
function TeacherClasses({ teacherId }: { teacherId: number }) {
  const teacherClasses = trpc.teacher.getClasses.useQuery({ teacherId });
  const removeClass = trpc.teacher.removeClass.useMutation();
  const utils = trpc.useUtils();

  const handleRemove = async (classId: number) => {
    await removeClass.mutateAsync({ teacherId, classId });
    utils.teacher.getClasses.invalidate({ teacherId });
    toast.success("Clase desasignada");
  };

  if (!teacherClasses.data?.length) {
    return <span className="text-muted-foreground text-sm">Sin clases</span>;
  }

  return (
    <div className="flex flex-wrap gap-1">
      {teacherClasses.data.map((tc) => (
        <Badge 
          key={tc.classId} 
          variant="secondary"
          className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
          onClick={() => handleRemove(tc.classId)}
        >
          {tc.classCode} ×
        </Badge>
      ))}
    </div>
  );
}
