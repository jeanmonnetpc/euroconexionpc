# EuroconexiónPC - TODO

## Sistema de Autenticación
- [x] Sistema de autenticación con tres tipos de acceso (alumno, profesor, administrador)
- [x] Registro automático de alumnos con formulario inicial (nombre, clase, código)
- [x] Acceso directo para alumnos ya registrados
- [x] Login de profesor con email y contraseña asignada
- [x] Login de administrador con contraseña única
- [x] Cambio de contraseña para profesores y administrador

## Perfil de Administrador
- [x] Pestaña para dar de alta profesores
- [x] Pestaña para eliminar profesores
- [x] Asignar clases a profesores
- [x] Pestaña para eliminar alumnos registrados
- [x] Pestaña de ranking global de todas las clases
- [x] Opción de resetear ranking
- [x] Opción de eliminar alumnos del ranking

## Perfil de Profesor
- [x] Vista de alumnos asignados por clase
- [x] Puntuaciones ordenadas de mayor a menor
- [x] Opción de eliminar entradas de alumnos

## Perfil de Alumno
- [x] Pestaña de contenidos: Historia de la Unión Europea
- [x] Pestaña de contenidos: 40 años de España en la UE
- [x] Pestaña de actividades de gamificación

## Sistema de Gamificación
- [x] Quiz 1: Nivel fácil (15 preguntas)
- [x] Quiz 2: Nivel moderado (15 preguntas)
- [x] Quiz 3: Nivel difícil (15 preguntas)
- [x] Juego de rol de eurodiputados
- [x] Escape room con 10 acertijos secuenciales

## Sistema de Puntuación y Rankings
- [x] Guardar resultados de alumnos automáticamente
- [x] Mostrar ranking en perfil del profesor por clase
- [x] Ranking global para administrador

## Diseño Visual
- [x] Diseño temático de la Unión Europea
- [x] Elementos de las Acciones Jean Monnet
- [x] Marca 'Cofinanciado por la EU'
- [x] Estilo elegante e institucional


## Mejoras Solicitadas
- [x] Ampliar y mejorar sección Historia de la UE con contenido pedagógico
- [x] Añadir imágenes históricas y educativas (mapas, fotos, iconos)
- [x] Organizar contenido con subtítulos claros y bloques breves
- [x] Incluir líneas del tiempo interactivas
- [x] Añadir preguntas motivadoras para el alumnado

- [x] Ampliar sección 40 años de España en la UE con enfoque pedagógico
- [x] Añadir contenido sobre beneficios de la adhesión española
- [x] Incluir imágenes y datos concretos
- [x] Añadir preguntas motivadoras

- [x] Crear componente de glosario interactivo con tooltips
- [x] Crear página dedicada al glosario con todos los términos UE
- [x] Integrar términos del glosario en las secciones de contenido
