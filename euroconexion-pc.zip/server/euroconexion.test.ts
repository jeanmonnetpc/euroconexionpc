import { describe, expect, it, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Create a mock context for testing
function createMockContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("EuroconexiónPC API", () => {
  const ctx = createMockContext();
  const caller = appRouter.createCaller(ctx);

  describe("Admin Routes", () => {
    it("should check if admin exists", async () => {
      const result = await caller.admin.exists();
      expect(result).toHaveProperty("exists");
      expect(typeof result.exists).toBe("boolean");
    });
  });

  describe("Class Routes", () => {
    it("should list all classes", async () => {
      const result = await caller.class.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("should return undefined for non-existent class code", async () => {
      const result = await caller.class.getByCode({ code: "NONEXISTENT123" });
      expect(result).toBeUndefined();
    });
  });

  describe("Teacher Routes", () => {
    it("should list all teachers", async () => {
      const result = await caller.teacher.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("should fail login with invalid credentials", async () => {
      const result = await caller.teacher.login({
        email: "invalid@test.com",
        password: "wrongpassword",
      });
      expect(result.success).toBe(false);
      expect(result.teacher).toBeNull();
    });
  });

  describe("Student Routes", () => {
    it("should list all students", async () => {
      const result = await caller.student.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("should check student existence with invalid class code", async () => {
      const result = await caller.student.checkExists({
        name: "Test Student",
        classCode: "INVALID123",
      });
      expect(result.classExists).toBe(false);
      expect(result.exists).toBe(false);
    });

    it("should fail registration with invalid class code", async () => {
      const result = await caller.student.register({
        name: "Test Student",
        classCode: "INVALID123",
      });
      expect(result.success).toBe(false);
      expect(result.message).toBe("Código de clase no válido");
    });
  });

  describe("Ranking Routes", () => {
    it("should get global ranking", async () => {
      const result = await caller.ranking.global();
      expect(Array.isArray(result)).toBe(true);
    });
  });
});
