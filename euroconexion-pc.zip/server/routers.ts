import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============ ADMIN ROUTES ============
  admin: router({
    // Verificar contraseña del administrador
    login: publicProcedure
      .input(z.object({ password: z.string() }))
      .mutation(async ({ input }) => {
        const isValid = await db.verifyAdminPassword(input.password);
        return { success: isValid };
      }),
    
    // Obtener o crear admin (primera vez)
    setup: publicProcedure
      .input(z.object({ password: z.string() }))
      .mutation(async ({ input }) => {
        const existing = await db.getAdmin();
        if (existing) {
          return { success: false, message: "Admin ya existe" };
        }
        await db.createOrUpdateAdmin(input.password);
        return { success: true };
      }),
    
    // Verificar si existe admin
    exists: publicProcedure.query(async () => {
      const admin = await db.getAdmin();
      return { exists: !!admin };
    }),
    
    // Cambiar contraseña
    changePassword: publicProcedure
      .input(z.object({ 
        currentPassword: z.string(), 
        newPassword: z.string() 
      }))
      .mutation(async ({ input }) => {
        const isValid = await db.verifyAdminPassword(input.currentPassword);
        if (!isValid) {
          return { success: false, message: "Contraseña actual incorrecta" };
        }
        await db.createOrUpdateAdmin(input.newPassword);
        return { success: true };
      }),
  }),

  // ============ TEACHER ROUTES ============
  teacher: router({
    // Login de profesor
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async ({ input }) => {
        const teacher = await db.getTeacherByEmail(input.email);
        if (!teacher || teacher.password !== input.password) {
          return { success: false, teacher: null };
        }
        return { success: true, teacher };
      }),
    
    // Obtener todos los profesores
    list: publicProcedure.query(async () => {
      return await db.getAllTeachers();
    }),
    
    // Obtener profesor por ID
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getTeacherById(input.id);
      }),
    
    // Crear profesor
    create: publicProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email(),
        password: z.string(),
      }))
      .mutation(async ({ input }) => {
        const existing = await db.getTeacherByEmail(input.email);
        if (existing) {
          return { success: false, message: "El email ya está registrado" };
        }
        const id = await db.createTeacher(input);
        return { success: true, id };
      }),
    
    // Eliminar profesor
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteTeacher(input.id);
        return { success: true };
      }),
    
    // Cambiar contraseña
    changePassword: publicProcedure
      .input(z.object({
        id: z.number(),
        currentPassword: z.string(),
        newPassword: z.string(),
      }))
      .mutation(async ({ input }) => {
        const teacher = await db.getTeacherById(input.id);
        if (!teacher || teacher.password !== input.currentPassword) {
          return { success: false, message: "Contraseña actual incorrecta" };
        }
        await db.updateTeacherPassword(input.id, input.newPassword);
        return { success: true };
      }),
    
    // Obtener clases asignadas
    getClasses: publicProcedure
      .input(z.object({ teacherId: z.number() }))
      .query(async ({ input }) => {
        return await db.getTeacherClasses(input.teacherId);
      }),
    
    // Asignar clase
    assignClass: publicProcedure
      .input(z.object({ teacherId: z.number(), classId: z.number() }))
      .mutation(async ({ input }) => {
        await db.assignClassToTeacher(input.teacherId, input.classId);
        return { success: true };
      }),
    
    // Quitar clase
    removeClass: publicProcedure
      .input(z.object({ teacherId: z.number(), classId: z.number() }))
      .mutation(async ({ input }) => {
        await db.removeClassFromTeacher(input.teacherId, input.classId);
        return { success: true };
      }),
    
    // Obtener ranking de una clase
    getClassRanking: publicProcedure
      .input(z.object({ classId: z.number() }))
      .query(async ({ input }) => {
        return await db.getClassRanking(input.classId);
      }),
  }),

  // ============ CLASS ROUTES ============
  class: router({
    list: publicProcedure.query(async () => {
      return await db.getAllClasses();
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getClassById(input.id);
      }),
    
    getByCode: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        return await db.getClassByCode(input.code);
      }),
    
    create: publicProcedure
      .input(z.object({ name: z.string(), code: z.string() }))
      .mutation(async ({ input }) => {
        const existing = await db.getClassByCode(input.code);
        if (existing) {
          return { success: false, message: "El código de clase ya existe" };
        }
        const id = await db.createClass(input);
        return { success: true, id };
      }),
    
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteClass(input.id);
        return { success: true };
      }),
  }),

  // ============ STUDENT ROUTES ============
  student: router({
    // Verificar si alumno existe
    checkExists: publicProcedure
      .input(z.object({ name: z.string(), classCode: z.string() }))
      .query(async ({ input }) => {
        const classData = await db.getClassByCode(input.classCode);
        if (!classData) {
          return { exists: false, student: null, classExists: false };
        }
        const student = await db.getStudentByNameAndClass(input.name, classData.id);
        if (student) {
          await db.updateStudentLastAccess(student.id);
        }
        return { exists: !!student, student, classExists: true };
      }),
    
    // Registrar nuevo alumno
    register: publicProcedure
      .input(z.object({ name: z.string(), classCode: z.string() }))
      .mutation(async ({ input }) => {
        const classData = await db.getClassByCode(input.classCode);
        if (!classData) {
          return { success: false, message: "Código de clase no válido" };
        }
        
        const existing = await db.getStudentByNameAndClass(input.name, classData.id);
        if (existing) {
          return { success: false, message: "Ya existe un alumno con ese nombre en esta clase" };
        }
        
        const id = await db.createStudent({ name: input.name, classId: classData.id });
        const student = await db.getStudentById(id!);
        return { success: true, student };
      }),
    
    // Obtener todos los alumnos
    list: publicProcedure.query(async () => {
      return await db.getAllStudents();
    }),
    
    // Obtener alumnos por clase
    listByClass: publicProcedure
      .input(z.object({ classId: z.number() }))
      .query(async ({ input }) => {
        return await db.getStudentsByClass(input.classId);
      }),
    
    // Obtener alumno por ID
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getStudentById(input.id);
      }),
    
    // Eliminar alumno
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteStudent(input.id);
        return { success: true };
      }),
    
    // Obtener progreso
    getProgress: publicProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        return await db.getStudentProgress(input.studentId);
      }),
    
    // Obtener puntuaciones
    getScores: publicProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        return await db.getStudentScores(input.studentId);
      }),
    
    // Guardar puntuación
    saveScore: publicProcedure
      .input(z.object({
        studentId: z.number(),
        activityType: z.enum(["quiz1", "quiz2", "quiz3", "roleplay", "escaperoom"]),
        score: z.number(),
        maxScore: z.number(),
        timeSpent: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.saveScore(input);
        
        // Actualizar progreso
        const progressField = {
          quiz1: "quiz1Completed",
          quiz2: "quiz2Completed",
          quiz3: "quiz3Completed",
          roleplay: "roleplayCompleted",
          escaperoom: "escaperoomCompleted",
        }[input.activityType];
        
        await db.updateStudentProgress(input.studentId, { [progressField]: true });
        
        return { success: true };
      }),
  }),

  // ============ RANKING ROUTES ============
  ranking: router({
    // Ranking global
    global: publicProcedure.query(async () => {
      return await db.getGlobalRanking();
    }),
    
    // Ranking por clase
    byClass: publicProcedure
      .input(z.object({ classId: z.number() }))
      .query(async ({ input }) => {
        return await db.getClassRanking(input.classId);
      }),
    
    // Resetear todo
    resetAll: publicProcedure.mutation(async () => {
      await db.resetAllRankings();
      return { success: true };
    }),
    
    // Resetear alumno
    resetStudent: publicProcedure
      .input(z.object({ studentId: z.number() }))
      .mutation(async ({ input }) => {
        await db.resetStudentRanking(input.studentId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
