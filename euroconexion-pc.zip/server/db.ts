import { eq, and, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  admins, InsertAdmin,
  teachers, InsertTeacher,
  classes, InsertClass,
  teacherClasses, InsertTeacherClass,
  students, InsertStudent,
  scores, InsertScore,
  studentProgress, InsertStudentProgress
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER FUNCTIONS ============
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ ADMIN FUNCTIONS ============
export async function getAdmin() {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(admins).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateAdmin(password: string) {
  const db = await getDb();
  if (!db) return;
  
  const existing = await getAdmin();
  if (existing) {
    await db.update(admins).set({ password }).where(eq(admins.id, existing.id));
  } else {
    await db.insert(admins).values({ password });
  }
}

export async function verifyAdminPassword(password: string) {
  const admin = await getAdmin();
  if (!admin) return false;
  return admin.password === password;
}

// ============ TEACHER FUNCTIONS ============
export async function getAllTeachers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(teachers);
}

export async function getTeacherById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(teachers).where(eq(teachers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getTeacherByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(teachers).where(eq(teachers.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createTeacher(data: { name: string; email: string; password: string }) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(teachers).values(data);
  return result[0].insertId;
}

export async function updateTeacherPassword(id: number, password: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(teachers).set({ password }).where(eq(teachers.id, id));
}

export async function deleteTeacher(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(teacherClasses).where(eq(teacherClasses.teacherId, id));
  await db.delete(teachers).where(eq(teachers.id, id));
}

// ============ CLASS FUNCTIONS ============
export async function getAllClasses() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(classes);
}

export async function getClassById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(classes).where(eq(classes.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getClassByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(classes).where(eq(classes.code, code)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createClass(data: { name: string; code: string }) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(classes).values(data);
  return result[0].insertId;
}

export async function deleteClass(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(teacherClasses).where(eq(teacherClasses.classId, id));
  await db.delete(classes).where(eq(classes.id, id));
}

// ============ TEACHER-CLASS FUNCTIONS ============
export async function getTeacherClasses(teacherId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select({
      id: teacherClasses.id,
      classId: teacherClasses.classId,
      className: classes.name,
      classCode: classes.code,
    })
    .from(teacherClasses)
    .innerJoin(classes, eq(teacherClasses.classId, classes.id))
    .where(eq(teacherClasses.teacherId, teacherId));
  
  return result;
}

export async function assignClassToTeacher(teacherId: number, classId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Check if already assigned
  const existing = await db
    .select()
    .from(teacherClasses)
    .where(and(eq(teacherClasses.teacherId, teacherId), eq(teacherClasses.classId, classId)))
    .limit(1);
  
  if (existing.length === 0) {
    await db.insert(teacherClasses).values({ teacherId, classId });
  }
}

export async function removeClassFromTeacher(teacherId: number, classId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(teacherClasses).where(
    and(eq(teacherClasses.teacherId, teacherId), eq(teacherClasses.classId, classId))
  );
}

// ============ STUDENT FUNCTIONS ============
export async function getAllStudents() {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select({
      id: students.id,
      name: students.name,
      classId: students.classId,
      className: classes.name,
      classCode: classes.code,
      createdAt: students.createdAt,
      lastAccess: students.lastAccess,
    })
    .from(students)
    .innerJoin(classes, eq(students.classId, classes.id));
}

export async function getStudentsByClass(classId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select({
      id: students.id,
      name: students.name,
      classId: students.classId,
      createdAt: students.createdAt,
      lastAccess: students.lastAccess,
    })
    .from(students)
    .where(eq(students.classId, classId));
}

export async function getStudentByNameAndClass(name: string, classId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(students)
    .where(and(eq(students.name, name), eq(students.classId, classId)))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

export async function getStudentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(students).where(eq(students.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createStudent(data: { name: string; classId: number }) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.insert(students).values(data);
  const studentId = result[0].insertId;
  
  // Create progress record
  await db.insert(studentProgress).values({ studentId });
  
  return studentId;
}

export async function updateStudentLastAccess(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(students).set({ lastAccess: new Date() }).where(eq(students.id, id));
}

export async function deleteStudent(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(scores).where(eq(scores.studentId, id));
  await db.delete(studentProgress).where(eq(studentProgress.studentId, id));
  await db.delete(students).where(eq(students.id, id));
}

// ============ SCORE FUNCTIONS ============
export async function getStudentScores(studentId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(scores).where(eq(scores.studentId, studentId));
}

export async function saveScore(data: InsertScore) {
  const db = await getDb();
  if (!db) return;
  
  await db.insert(scores).values(data);
  
  // Update total points in progress
  const allScores = await getStudentScores(data.studentId);
  const totalPoints = allScores.reduce((sum, s) => sum + s.score, 0);
  
  await db.update(studentProgress)
    .set({ totalPoints })
    .where(eq(studentProgress.studentId, data.studentId));
}

export async function getStudentProgress(studentId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db
    .select()
    .from(studentProgress)
    .where(eq(studentProgress.studentId, studentId))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

export async function updateStudentProgress(studentId: number, data: Partial<InsertStudentProgress>) {
  const db = await getDb();
  if (!db) return;
  await db.update(studentProgress).set(data).where(eq(studentProgress.studentId, studentId));
}

// ============ RANKING FUNCTIONS ============
export async function getClassRanking(classId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select({
      studentId: students.id,
      studentName: students.name,
      totalPoints: studentProgress.totalPoints,
      quiz1Completed: studentProgress.quiz1Completed,
      quiz2Completed: studentProgress.quiz2Completed,
      quiz3Completed: studentProgress.quiz3Completed,
      roleplayCompleted: studentProgress.roleplayCompleted,
      escaperoomCompleted: studentProgress.escaperoomCompleted,
    })
    .from(students)
    .innerJoin(studentProgress, eq(students.id, studentProgress.studentId))
    .where(eq(students.classId, classId))
    .orderBy(desc(studentProgress.totalPoints));
}

export async function getGlobalRanking() {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select({
      studentId: students.id,
      studentName: students.name,
      classId: students.classId,
      className: classes.name,
      totalPoints: studentProgress.totalPoints,
      quiz1Completed: studentProgress.quiz1Completed,
      quiz2Completed: studentProgress.quiz2Completed,
      quiz3Completed: studentProgress.quiz3Completed,
      roleplayCompleted: studentProgress.roleplayCompleted,
      escaperoomCompleted: studentProgress.escaperoomCompleted,
    })
    .from(students)
    .innerJoin(studentProgress, eq(students.id, studentProgress.studentId))
    .innerJoin(classes, eq(students.classId, classes.id))
    .orderBy(desc(studentProgress.totalPoints));
}

export async function resetAllRankings() {
  const db = await getDb();
  if (!db) return;
  
  await db.update(studentProgress).set({
    totalPoints: 0,
    quiz1Completed: false,
    quiz2Completed: false,
    quiz3Completed: false,
    roleplayCompleted: false,
    escaperoomCompleted: false,
  });
  
  await db.delete(scores);
}

export async function resetStudentRanking(studentId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db.update(studentProgress).set({
    totalPoints: 0,
    quiz1Completed: false,
    quiz2Completed: false,
    quiz3Completed: false,
    roleplayCompleted: false,
    escaperoomCompleted: false,
  }).where(eq(studentProgress.studentId, studentId));
  
  await db.delete(scores).where(eq(scores.studentId, studentId));
}
